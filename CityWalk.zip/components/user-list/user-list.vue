<template>
	<view class="p-2 flex align-center mx-3 border-bottom border-light" hover-class="bg-light">
		<image class="rounded-circle mr-3 mt-1" :src="item.avatar" mode="" style="height: 100rpx; width: 100rpx;">
		</image>
		<view class="flex-1 grid">
			<text class="font-md text-dark">{{ item.user_nick_name }}</text>
			<uni-badge :text="item.age" :type="item.sex === 2 ? 'error' : 'primary'" style="width: 20%;" class="mt-1"
				size="small">
				<text v-if="item.sex > 0" class="iconfont mr-1"
					:class="item.sex === 1 ? 'icon-xingbie-nan' : 'icon-xingbie-nv'"></text>
			</uni-badge>
		</view>
		<view class="uni-icon uni-icon-checkbox-filled" :class="item.isFollow ? 'text-main' : 'text-light-muted'">
		</view>
	</view>
</template>

<script>
	import uniBadge from "../../components/uni-ui/uni-badge/components/uni-badge/uni-badge.vue";

	export default {
		components: {
			uniBadge
		},
		props: {
			item: Object,
			index: Number
		}
	}
</script>

<style>
</style>