<template>
	<div>
		<div id="container"></div>
		<div class="info">
			<div class="input-item">
				<div class="input-item-prepend">
					<span class="input-item-text" style="width: 8rem;">请输入关键字</span>
				</div>
				<input id="tipinput" type="text" />
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		mounted() {
			this.initMap();
		},
		methods: {
			initMap() {
				const map = new AMap.Map("container", {
					resizeEnable: true,
				});

				// 输入提示
				const auto = new AMap.Autocomplete({
					input: "tipinput",
				});
			},
		},
	};
</script>

<style scoped>
	html,
	body,
	#container {
		width: 100%;
		height: 100%;
	}
</style>