<template>
	<view class="settings">
		<!-- 头部 -->
		<view class="settings-header">
			<text class="settings-title">设置</text>
		</view>

		<!-- 设置项 -->
		<view class="settings-items">
			<!-- 设置项 - 账号与安全 -->
			<view class="settings-item" @click="open('user-password')">
				<text class="settings-item-label">账号与安全</text>
			</view>

			<!-- 设置项 - 清除缓存 -->
			<view class="settings-item" @click="clearCache">
				<text class="settings-item-label">清除缓存</text>
				<text class="settings-item-info">{{currentSize | format}}</text>
			</view>

			<!-- 设置项 - 关于 CityWalk -->
			<view class="settings-item">
				<text class="settings-item-label">关于 CityWalk</text>
				<text class="settings-item-info">版本 1.0.0</text>
			</view>

			<!-- 退出登录按钮 -->
			<button class="btn btn-danger btn-block" @click="logout">退出登录</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				currentSize: 0
			}
		},
		onLoad() {
			this.getStorageInfo()
		},
		filters: {
			format(value) {
				return value > 1024 ? (value / 1024).toFixed(2) + 'MB' : value.toFixed(2) + 'KB';
			}
		},
		methods: {
			getStorageInfo() {
				let res = uni.getStorageInfoSync()
				this.currentSize = res.currentSize
			},
			open(path) {
				// 跳转到界面【账号，资料】
				console.log('跳转到' + `${path}`);
				uni.navigateTo({
					url: `../${path}/${path}`
				})
			},
			clearCache() {
				uni.showModal({
					title: '提示',
					content: '是否要清除所有缓存？',
					cancelText: '不清除',
					confirmText: '清除',
					success: res => {
						if (res.confirm) {
							uni.clearStorageSync()
							this.getStorageInfo()
							uni.showToast({
								title: '清除成功',
								icon: 'none'
							});
						}
					},
				});
			},
			logout() {
				// 点击退出登录按钮执行的逻辑
				console.log('退出登录');
				uni.navigateTo({
					url: '/pages/login/login'
				})
			}
		}
	};
</script>

<style lang="scss" scoped>
	.settings {
		padding: 20px;
		font-size: 16px;

		.settings-header {
			text-align: center;
			font-size: 20px;
			font-weight: bold;
			margin-bottom: 20px;
		}

		.settings-items {
			.settings-item {
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 10px 0;
				border-bottom: 1px solid #eee;
				cursor: pointer;
				transition: background-color 0.3s;

				&:last-child {
					border-bottom: none;
				}

				.settings-item-label {
					flex: 1;
				}

				.settings-item-info {
					color: #666;
				}

				&:hover {
					background-color: #f7f7f7;
				}
			}

		}
	}
</style>