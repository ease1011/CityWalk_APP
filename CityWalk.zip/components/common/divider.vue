<template>

	<view style="height: 15rpx;
	background-color: #dedede; 
	margin: 10px 0; "></view>
</template>

<script>
</script>

<style>
</style>