<template>
	<view class="p-3">
		<!-- 头像昵称|关注按钮 -->
		<view class="header-container">
			<!-- 头像 -->
			<image :src="item.user_avatar" @click="openSpace" class="avatar rounded" lazy-load></image>
			<!-- 昵称+发布时间 -->
			<view class="info-container">
				<view class="nickname">{{item.user_nick_name}}</view>
				<!-- <text class="time">{{ formattedTime(item.create_time)}}</text> -->
				<text class="time">{{ item.create_time}}</text>
			</view>
			<!-- 关注按钮 -->
			<!-- <view v-if="!item.isFollow" @click="follow" class="follow-button rounded-3 animated"
				hover-class="heartBeat">关注</view> -->
		</view>
		<!-- 标题 -->
		<view class="title" @click="openDetail">{{item.description}}</view>
		<!-- 帖子详情 -->
		<slot>
			<!-- 图片 -->
			<view @click="openDetail" v-if="item.image_url" class="image-container">
				<image :src="item.image_url" class="image rounded-2"></image>
			</view>
		</slot>
		<!-- 图标按钮 -->
		<view class="icon-buttons">
			<!-- 首页-点赞 -->
			<view @click="doLike(item.like.type)" class="icon-button animated faster" hover-class="swing text-main"
				:class="{ 'text-main': item.like.type}">
				<text class="iconfont icon-dianzan font-lg"></text>
				<text>{{item.like.likeCount}}</text>
			</view>
			<!-- 首页-收藏 -->
			<view @click="doFavorite(item.favorite.type)" class="icon-button animated faster"
				hover-class="swing text-main" :class="{ 'text-main': item.favorite.type}">
				<text class="iconfont icon-shoucang font-lg"></text>
				<text>{{item.favorite.favoriteCount}}</text>
			</view>
			<!-- 首页-评论 -->
			<view class="icon-button animated faster" hover-class="swing text-main" @click="doComment">
				<text class="iconfont icon-pinglun font-lg"></text>
				<text>{{item.commentCount}}</text>
			</view>
			<!-- 首页-分享 -->
			<!-- <view class="icon-button animated faster" hover-class="swing text-main" @click="doShare">
				<text class="iconfont icon-zhuanfaxing font-lg"></text>
				<text>{{item.shareCount}}</text>
			</view> -->
		</view>
	</view>
</template>

<script>
	export default {
		props: {
			item: Object,
			index: {
				type: Number,
				default: -1
			},
			isDetail: {
				type: Boolean,
				default: false
			},
		},
		computed: {},
		methods: {
			// 打开个人空间
			openSpace() {
				if (this.item.UserId === getApp().globalData.C_UserId) {
					uni.switchTab({
						url: '/pages/mine/mine'
					})
				} else {
					uni.navigateTo({
						url: "/pages/user-space/user-space?id=" + this.item.UserId
					});
				}
				console.log('打开个人空间', this.item)
			},
			// 关注
			follow() {
				// 通知父组件，
				this.$emit('follow', this.index)
				console.log('关注了')
			},
			// 进入详情页
			openDetail() {
				if (this.isDetail) return;
				uni.navigateTo({
					url: "/pages/detail/detail?id=" + this.item.PostId
				})
				console.log('打开详情页')
			},
			// 点赞
			doLike(type) {
				this.$emit('doLike', {
					type: type,
					index: this.index
				});
			},
			doFavorite(type) {
				this.$emit('doFavorite', {
					type: type,
					index: this.index
				});
			},
			doShare() {
				if (!this.isDetail) {
					return this.openDetail()
				}
				this.$emit('doShare')
			},
			doComment() {
				if (!this.isDetail) {
					return this.openDetail()
				}
				this.$emit('doComment')
			},

		}
	}
</script>

<style>
</style>