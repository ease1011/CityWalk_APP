<template>
	<div class="search-page">
		<!-- 搜索框 -->
		<div class="search-container">
			<div class="search-box flex">
				<input type="text" v-model="searchText" placeholder="请输入搜索关键词" class="search-input">
				<button @click="searchEvent" class="search-button">搜索</button>
			</div>
			<!-- 搜索历史 -->
			<div v-if="isSearch" class="search-history">
				<div class="title">搜索历史</div>
				<div class="history-list">
					<div class="history-item" v-for="(item, index) in list" :key="index"
						@click="clickSearchHistory(item)">
						{{item}}
					</div>
				</div>
				<!-- 清空搜索历史 -->
				<div class="clear-history" @click="clearSearchHistory">清空搜索历史</div>
			</div>
		</div>
		<!-- 搜索结果 -->
		<div class="search-results mt-5" v-if="!isNothing">
			<!-- 用户 -->
			<div v-if="isUser" class="swiper-container">
				<div class="swiper-wrapper user-section">
					<div class="swiper-slide" v-for="(user, index) in users" :key="index" @click="navigateToUser(user)">
						<div class="user-item">
							<img :src="user.avatar" class="avatar">
							<div class="nick-name">{{ user.user_nick_name }}</div>
						</div>
					</div>
				</div>
			</div>
			<!-- 商铺 -->
			<div v-if="isBusiness" class="swiper-container">
				<div class="swiper-wrapper business-section">
					<div class="swiper-slide" v-for="(business, index) in businesses" :key="index"
						@click="navigateToBusiness(business)">
						<div class="business-item">
							<img :src="business.imageUrls" class="business-avatar">
							<div class="business-details">
								<div class="business-name">{{ business.name }}</div>
								<div class="business-description">{{ business.description }}</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- 话题 -->
			<div v-if="isTopic" class="swiper-container">
				<div class="swiper-wrapper topic-section">
					<div class="swiper-slide" v-for="(topic, index) in topics" :key="index"
						@click="navigateToTopic(topic)">
						<div class="topic-item">
							<img :src="topic.coverImage" class="topic-cover">
							<div class="topic-details">
								<div class="topic-title">{{ topic.title }}</div>
								<div class="topic-description">{{ topic.description }}</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- 帖子 -->
			<div v-if="isPost" class="swiper-container">
				<div class="swiper-wrapper post-section">
					<div class="swiper-slide" v-for="(post, index) in posts" :key="index" @click="navigateToPost(post)">
						<div class="post-item">
							<img :src="post.image_url" class="post-image">
							<div class="post-details">
								<div class="post-description">{{ post.description }}</div>
								<div class="post-username">{{ post.username }}</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- 无搜索结果时的提示 -->
		<div v-if="isNothing">
			<no-thing></no-thing>
		</div>
	</div>
</template>

<script>
	import noThing from '@/components/common/no-thing.vue'
	export default {
		components: {
			noThing
		},
		data() {
			return {
				isSearch: true,
				isNothing: false,
				isUser: false,
				isTopic: false,
				isBusiness: false,
				isPost: false,
				searchText: "",
				list: JSON.parse(localStorage.getItem("searchHistory")) || ['city'],
				type: 'post',
				users: [],
				topics: [],
				posts: [],
				businesses: [],
			}
		},
		methods: {
			navigateToUser(user) {
				uni.navigateTo({
					url: "/pages/user-space/user-space?id=" + user.id
				});
			},
			navigateToBusiness(business) {
				uni.navigateTo({
					url: "/pages/business-detail/business-detail?id=" + business.id
				});
			},
			navigateToPost(post) {
				uni.navigateTo({
					url: "/pages/detail/detail?id=" + post.id
				})
			},
			navigateToTopic(topic) {
				uni.navigateTo({
					url: "/pages/topic-detail/topic-detail?id=" + topic.id
				})
			},
			clearSearchHistory() {
				this.list = []; // 清空历史记录
				localStorage.removeItem("searchHistory"); // 从本地存储中移除搜索历史
			},
			clickSearchHistory(text) {
				this.searchText = text
				this.searchEvent()
			},
			searchEvent() {
				const keyword = this.searchText.trim();
				if (!keyword) return; // 如果搜索关键词为空，则不进行搜索
				// 将搜索关键词添加到搜索历史中
				this.list.unshift(keyword);
				// 将搜索历史存储在本地存储中
				if (this.list.length > 20) {
					this.list.pop(); // 如果历史记录数量超过20条，则删除最早的历史记录
				}
				localStorage.setItem("searchHistory", JSON.stringify(this.list));
				uni.request({
					url: `http://127.0.0.1:8002/api/search/${keyword}`,
					method: 'GET',
					success: (res) => {
						console.log(res.data);
						this.users = res.data.users;
						this.topics = res.data.topics;
						this.posts = res.data.posts;
						this.businesses = res.data.businesses;
						console.log(this);
						if (this.users.length === 0 && this.topics.lenght === 0 && this.businesses.length ===
							0 && this.posts.length === 0) {
							this.isNothing = true
						} else {
							if (this.users.length > 0) this.isUser = true
							if (this.topics.length > 0) this.isTopic = true
							if (this.businesses.length > 0) this.isBusiness = true
							if (this.posts.length > 0) {
								this.isPost = true
								for (let i = 0; i < this.posts.length; i++) {
									this.posts[i].image_url = JSON.parse(this.posts[i].image_url)[0]
								}
							}
							this.isNothing = false
						}
						this.isSearch = false
					},
					fail: (err) => {
						console.error("网络请求失败:", err);
					},
				});
			},

		},

	}
</script>

<style scoped>
	.search-page {
		padding: 20px;
	}

	.search-container {
		margin-bottom: 20px;
	}

	.search-input {
		height: 45px;
		flex: 1;
		padding: 10px;
		font-size: 16px;
		border: 1px solid #ccc;
		border-radius: 14px;
	}

	.search-button {
		padding: 10px 20px;
		margin-left: 10px;
		font-size: 16px;
		background-color: #007bff;
		color: #fff;
		border: none;
		border-radius: 12px;
		cursor: pointer;
		transition: background-color 0.3s ease;
	}

	.search-button:hover {
		background-color: #0056b3;
	}

	.search-history {
		margin-top: 20px;
	}

	.title {
		font-size: 18px;
		font-weight: bold;
		margin-bottom: 10px;
	}

	.history-list {
		display: flex;
		flex-wrap: wrap;
	}

	.history-item {
		padding: 5px 10px;
		margin-right: 10px;
		margin-bottom: 10px;
		border: 1px solid #ccc;
		border-radius: 5px;
		cursor: pointer;
		transition: background-color 0.3s ease;
	}

	.history-item:hover {
		background-color: #f0f0f0;
	}

	.search-results {
		margin-top: 10px;
	}

	.swiper-container {
		overflow-x: auto;
		white-space: nowrap;
	}

	.swiper-slide {
		display: inline-block;
		vertical-align: top;
	}

	/* 用户样式 */
	.user-section {
		display: flex;
	}




	.avatar {
		width: 50px;
		height: 50px;
		border-radius: 50%;
		box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
	}

	.nick-name {
		margin-top: 5px;
	}

	/* 商铺样式 */
	.business-section {
		display: flex;
	}



	.business-avatar {
		width: 100px;
		height: 100px;
		border-radius: 5px;
		margin-bottom: 10px;
	}

	.business-details {
		text-align: center;
	}

	.business-name {
		font-size: 16px;
		font-weight: bold;
		margin-bottom: 5px;
	}

	.business-description {
		font-size: 14px;
		color: #666;
	}

	/* 话题样式 */
	.topic-section {
		display: flex;
	}




	.topic-cover {
		width: 120px;
		height: 150px;
		border-radius: 5px;
		margin-right: 10px;
	}

	.topic-details {
		text-align: center;
	}

	.topic-title {
		font-size: 16px;
		font-weight: bold;
		margin-bottom: 5px;
	}

	.topic-description {
		font-size: 14px;
		color: #666;
	}

	/* 帖子样式 */
	.post-section {
		display: flex;
	}



	.post-image {
		width: 100px;
		height: 100px;
		border-radius: 5px;
		margin-right: 10px;
	}

	.post-details {
		text-align: center;
	}

	.post-description {
		font-size: 16px;
		margin-bottom: 5px;
	}

	.post-username {
		font-size: 14px;
		color: #666;
	}


	/* 用户样式 */
	.user-item {
		width: 100px;
		/* 设置固定宽度 */
		border: 1px solid #e0e0e0;
		/* 设置边框，淡一些 */
		padding: 10px;
		/* 添加内边距 */
		margin-right: 10px;
		text-align: center;
		white-space: nowrap;
		/* 防止换行 */
		overflow: hidden;
		/* 隐藏超出部分 */
		text-overflow: ellipsis;
		/* 超出部分显示为省略号 */
		margin-bottom: 20px;
		/* 添加下边距 */
		box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
		/* 添加阴影效果 */
	}

	/* 商铺样式 */
	.business-item {
		width: 140px;
		/* 设置固定宽度 */
		border: 1px solid #e0e0e0;
		/* 设置边框，淡一些 */
		padding: 10px;
		/* 添加内边距 */
		margin-right: 20px;
		text-align: center;
		white-space: nowrap;
		/* 防止换行 */
		overflow: hidden;
		/* 隐藏超出部分 */
		text-overflow: ellipsis;
		/* 超出部分显示为省略号 */
		margin-bottom: 20px;
		/* 添加下边距 */
		box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
		/* 添加阴影效果 */
	}

	/* 话题样式 */
	.topic-item {
		width: 140px;
		/* 设置固定宽度 */
		border: 1px solid #e0e0e0;
		/* 设置边框，淡一些 */
		padding: 10px;
		/* 添加内边距 */
		margin-right: 20px;
		white-space: nowrap;
		/* 防止换行 */
		overflow: hidden;
		/* 隐藏超出部分 */
		text-overflow: ellipsis;
		/* 超出部分显示为省略号 */
		margin-bottom: 20px;
		/* 添加下边距 */
		box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
		/* 添加阴影效果 */
	}

	/* 帖子样式 */
	.post-item {
		width: 140px;
		/* 设置固定宽度 */
		border: 1px solid #e0e0e0;
		/* 设置边框，淡一些 */
		padding: 10px;
		/* 添加内边距 */
		margin-right: 20px;
		white-space: nowrap;
		/* 防止换行 */
		overflow: hidden;
		/* 隐藏超出部分 */
		text-overflow: ellipsis;
		/* 超出部分显示为省略号 */
		margin-bottom: 20px;
		/* 添加下边距 */
		box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
		/* 添加阴影效果 */
	}

	/* 隐藏滚动条 */
	.swiper-container::-webkit-scrollbar {
		display: none;
	}

	/* Firefox */
	.swiper-container {
		scrollbar-width: none;
	}
</style>