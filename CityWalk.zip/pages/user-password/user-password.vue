<template>
	<div class="change-password">
		<!-- 标题 -->
		<div class="change-password-header">
			<h1 class="change-password-title">修改密码</h1>
		</div>

		<!-- 表单 -->
		<div class="change-password-form">
			<!-- 旧密码输入 -->
			<div class="form-group">
				<label class="form-label">旧密码</label>
				<input class="form-control" type="password" v-model="oldPassword" placeholder="输入旧密码">
			</div>

			<!-- 新密码输入 -->
			<div class="form-group">
				<label class="form-label">新密码</label>
				<input class="form-control" type="password" v-model="newPassword" placeholder="输入新密码">
				<p v-if="newPassword.length > 0 && !isValidNewPassword" class="error-text">
					密码必须至少包含8个字符，并且必须包含至少一个字母和一个数字
				</p>
			</div>

			<!-- 确认新密码输入 -->
			<div class="form-group">
				<label class="form-label">确认新密码</label>
				<input class="form-control" type="password" v-model="confirmPassword" placeholder="重新输入新密码">
				<p v-if="confirmPassword.length > 0 && newPassword !== confirmPassword" class="error-text">
					两次输入的密码不一致
				</p>
			</div>

			<!-- 提交按钮 -->
			<button class="btn btn-primary btn-block" :disabled="!isValidForm" @click="submit">确认修改</button>
		</div>
	</div>
</template>

<script>
	import axios from 'axios';
	export default {
		data() {
			return {
				oldPassword: '',
				newPassword: '',
				confirmPassword: '',
				passwordPattern: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/, // 密码验证规则
			};
		},
		computed: {
			isValidNewPassword() {
				return this.passwordPattern.test(this.newPassword);
			},
			isValidForm() {
				return this.isValidNewPassword && this.newPassword === this.confirmPassword;
			}
		},
		methods: {
			showToast(title, icon) {
				uni.showToast({
					title,
					icon,
				});
			},
			async submit() {
				// 验证新密码是否符合规则
				if (!this.isValidNewPassword) {
					this.showToast(
						'密码必须至少包含8个字符，并且必须包含至少一个字母和一个数字',
						'none');
					return;
				}
				// 验证新密码和确认密码是否一致
				if (this.newPassword !== this.confirmPassword) {
					this.showToast('两次输入的密码不一致', 'none');
					return;
				}
				// 调用 checkOldPassword API
				let username = getApp().globalData.C_Username; // 替换为实际用户名
				let response = await axios.get(
					`http://localhost:8002/api/user/checkOldPassword/${username}?oldPassword=${this.oldPassword}`);
				if (response.data) {
					// 如果旧密码正确，调用 updatePassword API
					let newPassword = {
						password: this.newPassword
					};
					// await axios.put(`http://localhost:8002/api/user/updatePassword/${username}`, this.newPassword);
					await axios.put(`http://localhost:8002/api/user/updatePassword/${username}`, newPassword);
					this.showToast('密码修改成功', 'success');
					// 成功修改后清空输入框
					this.oldPassword = '';
					this.newPassword = '';
					this.confirmPassword = '';
				} else {
					this.showToast('旧密码不正确', 'none');
				}
			}
		}
	};
</script>

<style lang="scss" scoped>
	.change-password {
		padding: 20px;
		font-size: 16px;

		.change-password-header {
			text-align: center;
			font-size: 20px;
			font-weight: bold;
			margin-bottom: 20px;
		}

		.change-password-form {
			.form-group {
				margin-bottom: 15px;
			}

			.form-label {
				margin-bottom: 5px;
				font-weight: bold;
				color: #333;
			}

			.form-control {
				width: 100%;
				height: 40px;
				padding: 5px 10px;
				border: 1px solid #ccc;
				border-radius: 4px;
				font-size: 16px;
			}

			.error-text {
				color: #ff4d4f;
				font-size: 12px;
				margin-top: 5px;
			}

			.btn-block {
				width: 100%;
				margin-top: 20px;
				height: 40px;
				background-color: #007bff;
				color: #fff;
				border: none;
				border-radius: 4px;
				font-size: 16px;
				cursor: pointer;

				&:hover {
					background-color: #0056b3;
				}

				&:disabled {
					background-color: #ccc;
					cursor: not-allowed;
				}
			}
		}
	}
</style>