<template>
	<view class="profile">
		<!-- <button class="btn btn-success " @click="fetchTabs">测试</button> -->
		<!-- 头部信息 -->
		<view class="profile-header">
			<!-- 背景图片 + 头像 + 用户名 + 编辑按钮-->
			<img class="profile-bg" :src="User.backgroundImage" alt="Background Image">
			<img class="profile-avatar" :src="User.avatar" alt="Avatar">
			<!-- <view class="profile-username">{{ User.username }}</view> -->
			<view class="profile-username">{{ User.user_nick_name }}</view>
			<view class="profile-bio">{{ User.bio }}</view>
			<view class="profile-info">
				<view class="info-item">关注: <text>{{ User.following }}</text></view>
				<view class="info-item">粉丝: <text>{{ User.followers }}</text></view>
				<view class="info-item">城市: <text>{{ User.city }}</text></view>
			</view>
			<button class="btn btn-primary profile-edit-btn" @click="editProfile">编辑个人资料</button>
		</view>

		<!-- 主要内容区域 -->
		<view class="container h-100">
			<!-- 选项卡 -->
			<view class="profile-tabs">
				<view class="profile-tab" v-for="(tab, index) in tabs" :key="index" @click="changeTab(index)"
					:class="{ 'active': activeTabIndex === index }">{{ tab.title }}
					<text class="font-sm text-secondary p-2"> {{tab.num}}</text>
				</view>
			</view>
			<!-- 内容 -->
			<view class="profile-posts">
				<view class="profile-post" v-for="post in TabPosts" :key="post.id" @click="openDetail(post)">
					<img :src="post.image_url" alt="Post Image">
					<view class="post-description p-2 mb-2">{{ post.description }}</view>
					<view class="border-bottom"></view>
				</view>
			</view>
		</view>
	</view>
</template>
<script>
	let userId = 0;
	export default {
		data() {
			return {
				User: {
					username: "BlueEEE🤣",
					user_nick_name: 'bulubulueee~',
					avatar: "/static/topicpic.jpg",
					backgroundImage: "/static/castle.jpg",
					bio: "想要散散步~",
					gender: "男",
					age: 11,
					city: "北京",
					hobbies: "旅行、摄影",
					following: 9,
					followers: 11,
					posts: [{
						id: 1,
						image_url: "/static/pic1 (1).jpeg",
						description: "这是我的第一条动态，欢迎大家关注！",
						create_time: ''
					}]
				},
				tabs: [{
						title: "笔记",
						posts: [],
						num: 0,
					},
					{
						title: "收藏",
						posts: [],
						num: 0,
					},
					{
						title: "点赞",
						posts: [],
						num: 0,
					},
					// {
					// 	title: "历史",
					// 	posts: [],
					// 	num: 0,
					// }
				],
				activeTabIndex: 0,
				swiperHeight: 0
			};
		},
		computed: {
			TabPosts() {
				return this.tabs[this.activeTabIndex].posts;

			}
		},
		onNavigationBarButtonTap() {
			uni.navigateTo({
				url: '/pages/user-set/user-set'
			})
		},
		onShow() {
			this.fetchData();
		},
		methods: {
			openDetail(post) {
				uni.navigateTo({
					url: "/pages/detail/detail?id=" + post.id,
					success: (res) => {
						console.log(res);
					}
				})
			},
			refreshPage(e) {
				const user = this.User;
				user.user_nick_name = e.user_nick_name
				user.username = e.username
				user.avatar = e.avatar
				user.backgroundImage = e.background_image
				user.bio = e.bio
				user.city = e.city
				user.followers = e.followers
				user.following = e.following
			},
			refreshTabs(e) {
				this.tabs[0].num = e.notesCount
				this.tabs[1].num = e.favoriteCount
				this.tabs[2].num = e.likeCount
				// this.tabs[3].num = e.historyCount
			},
			fetchData() {
				uni.request({
					url: 'http://127.0.0.1:8002/api/user/' + getApp().globalData.C_UserId,
					method: 'GET',
					success: (res) => {
						this.refreshPage(res.data)
						getApp().globalData.C_UserId = res.data.id;
						userId = res.data.id;
						uni.request({
							url: 'http://127.0.0.1:8002/api/usernotesstats/' + userId + '/stats',
							method: 'GET',
							success: (res) => {
								this.refreshTabs(res.data)
							}
						});
						uni.request({
							url: 'http://127.0.0.1:8002/api/user-relationship/user/' + userId +
								'/followers-count',
							method: 'GET',
							success: (res) => {
								this.User.followers = res.data
							}
						});
						uni.request({
							url: 'http://127.0.0.1:8002/api/user-relationship/user/' + userId +
								'/following-count',
							method: 'GET',
							success: (res) => {
								this.User.following = res.data
							}
						});
						uni.request({
							url: 'http://127.0.0.1:8002/api/post/' + userId + '/user/post',
							method: 'GET',
							success: (res) => {
								for (let i = 0; i < res.data.length; i++) {
									res.data[i].image_url = JSON.parse(res.data[i].image_url)[0]
								}
								this.User.posts = res.data
							}
						});
						uni.request({
							url: 'http://127.0.0.1:8002/api/user-favorite/' + userId +
								'/user/favorite/posts',
							method: 'GET',
							success: (res) => {
								for (let i = 0; i < res.data.length; i++) {
									res.data[i].image_url = JSON.parse(res.data[i].image_url)[0]
								}
								this.tabs[1].posts = res.data
							}
						});
						uni.request({
							url: 'http://127.0.0.1:8002/api/user-likes/' + userId +
								'/user/likes/posts',
							method: 'GET',
							success: (res) => {
								for (let i = 0; i < res.data.length; i++) {
									res.data[i].image_url = JSON.parse(res.data[i].image_url)[0]
								}
								this.tabs[2].posts = res.data
							}
						});
						// uni.request({
						// 	url: 'http://127.0.0.1:8002/api/user-history/' + userId +
						// 		'/user/history/posts',
						// 	method: 'GET',
						// 	success: (res) => {
						// 		for (let i = 0; i < res.data.length; i++) {
						// 			res.data[i].image_url = JSON.parse(res.data[i].image_url)[0]
						// 		}
						// 		this.tabs[3].posts = res.data
						// 	}
						// });
					},
					fail: (err) => {
						console.log('数据获取失败：', err);
					}
				});
			},
			editProfile() {
				uni.navigateTo({
					url: '/pages/user-userinfo/user-userinfo'
				})
			},
			changeTab(index) {
				this.activeTabIndex = index;
			},
			updatePosts() {
				this.tabs.forEach((tab, index) => {
					tab.posts = this.User.posts.filter(post => {
						if (index === 0) return true;
						if (index === 1 && post.collected) return true;
						if (index === 2 && post.liked) return true;
						return false;
					});
				});
			}
		},

		watch: {
			User: {
				handler() {
					this.updatePosts();
				},
				deep: true
			}
		}
	};
</script>
<style lang="scss" scoped>
	.profile {
		.profile-header {
			position: relative;
			text-align: center;

			.profile-bg {
				width: 100%;
				max-height: 200px;
				object-fit: cover;
			}

			.profile-avatar {
				width: 120px;
				height: 120px;
				border-radius: 50%;
				margin: -60px auto 20px;
				border: 3px solid #fff;
				box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
			}

			.profile-username {
				font-size: 24px;
				font-weight: bold;
				color: #333;
			}

			.profile-bio {
				margin-top: 10px;
				color: #666;
			}

			.profile-info {
				display: flex;
				justify-content: center;
				margin-top: 10px;

				.info-item {
					margin-right: 20px;
					color: #666;
					font-size: 14px;

					&:last-child {
						margin-right: 0;
					}

					text {
						font-weight: bold;
						margin-left: 5px;
					}
				}
			}

			.profile-edit-btn {
				margin-top: 10px;
			}
		}

		.container {
			padding: 10px;
		}

		.profile-tabs {
			display: flex;
			justify-content: space-around;
			background-color: #f9f9f9;
			padding: 10px 0;

			.profile-tab {
				padding: 10px;
				cursor: pointer;
				color: #666;
				font-weight: bold;
				border-bottom: 2px solid transparent;
				transition: border-color 0.3s;

				&.active {
					color: #333;
					border-bottom-color: #333;
				}
			}
		}

		.profile-posts {
			margin-top: 20px;

			.profile-post {
				margin-bottom: 20px;

				img {
					width: 100%;
					border-radius: 5px;
				}

				.post-description {
					margin-top: 10px;
				}
			}
		}
	}
</style>