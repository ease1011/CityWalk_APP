<template>
	<view class="p-2">
		<!-- 帖子详情页信息 -->
		<common-list :item="info" isDetail @doShare='doShare' @follow="follow" @doComment='doComment' @doLike='doLike'
			@doFavorite='doFavorite'>
			<view> {{info.content}} </view>
			<view v-for="(item,index) in info.images" :key="index" class="p-2">
				<image :src="item.url" mode="widthFix" class="w-100" @click="preview(index)"></image>
			</view>
			<view class="">
				<!-- 显示选中的地点 -->
				<div v-if="info.location" class="selected-item" @click="gotoBusinessDetail">
					<text class="iconfont icon-luxian"></text>
					# {{ info.location }}
				</div>
				<!-- 显示选中的话题 -->
				<div v-if="info.topic" class="selected-item" @click="gotoTopicDetail"><text
						class="iconfont icon-browse"></text>#
					{{ info.topic }}
				</div>
			</view>
		</common-list>
		<view v-if="info.UserId === post_User_id" @click="deletePost" class="delete-button btn btn-danger">
			删除帖子
		</view>

		<divider></divider>
		<view class="p-2 font-md font-weight-bold">
			最新评论 {{comments.length}}
		</view>
		<div v-for="(comments, index) in comments" :key="index" style="padding-bottom: 40px;">
			<div class="comment">
				<img class="avatar" :src="comments.avatar" alt="Avatar" @click="openSpace(comments.userId)">

				<div class="comment-details">
					<p class="nickname">{{ comments.user_nick_name }}</p>
					<p class="time">{{ comments.createTime}}</p>
					<p class="content">{{ comments.content }}</p>
					<view v-if="comments.userId === post_User_id" @click="deleteComment(index)" class="btn btn-danger">
						删除
					</view>

				</div>
			</div>
		</div>
		<view style="height=100rpx">
			<bottom-input @submit='submit'></bottom-input>
		</view>

	</view>
</template>

<script>
	var currentDate = new Date();
	var currentTime = currentDate.toLocaleString();
	import commonList from '@/components/common/common-list.vue'
	import bottomInput from '@/components/common/bottom-input.vue';
	import moreShare from '@/components/common/more-share.vue';
	export default {
		components: {
			commonList,
			bottomInput,
			moreShare,
		},

		data() {
			return {
				currentTimeStamp: new Date().getTime(),
				comments: [],
				post_User_id: getApp().globalData.C_UserId,
				info: { //当前帖子信息
					UserId: '',
					id: '',
					"user_nick_name": "",
					"user_avatar": "",
					"newstime": "",
					"isFollow": false,
					"title": "",
					"titlepic": "../../static/pic1.jpg",
					"like": {
						"type": false,
						"likeCount": 1
					},
					"favorite": {
						"type": false,
						"favoriteCount": 1
					},
					"commentCount": 1,
					"shareCount": 1,
					"create_time": '',
					content: "5月的上海实在太适合City Walk啦～ 周末花一点时间来慢慢感受一下老上海的文艺气息",
					images: [{ //数组
						url: ''
					}, ]
				}
			}
		},
		onLoad(e) {
			console.log(e.id)
			this.fetchData(e.id);
			console.log("当前时间：" + currentTime);
		},
		computed: {
			imagesList() {
				return this.info.images.map(item => item.url)
			}
		},

		methods: {
			openSpace(id) {
				if (id === getApp().globalData.C_UserId) {
					uni.switchTab({
						url: '/pages/mine/mine'
					})
				} else {
					uni.navigateTo({
						url: "/pages/user-space/user-space?id=" + id
					});
				}
				console.log('打开个人空间', id)
			},
			gotoBusinessDetail() {
				uni.navigateTo({
					url: "/pages/business-detail/business-detail?id=" + this.info.business_id
				})
			},
			gotoTopicDetail() {
				uni.navigateTo({
					url: "/pages/topic-detail/topic-detail?id=" + this.info.topic_id
				})
			},
			fetchData(id) {
				uni.request({ //通过post的id获取帖子详细数据
					url: `http://127.0.0.1:8002/api/post/${id}`,
					success: (res) => {
						this.info.content = res.data.post.detail;
						const imageUrlArray = JSON.parse(res.data.post.image_url);
						this.info.images = imageUrlArray.map(url => ({
							url
						}));
						this.info.favorite.favoriteCount = res.data.postStats.favoriteCount;
						this.info.like.likeCount = res.data.postStats.likeCount;
						uni.request({
							url: `http://127.0.0.1:8002/api/user-likes/${getApp().globalData.C_UserId}/post/${id}/likes`,
							method: 'GET',
							success: (res) => { //点赞状态
								this.info.like.type = res.data
							}
						});
						uni.request({
							url: `http://127.0.0.1:8002/api/user-favorite/${getApp().globalData.C_UserId}/post/${id}/favorite`,
							method: 'GET',
							success: (res) => { //点赞状态
								this.info.favorite.type = res.data
							}
						});
						this.info.shareCount = res.data.postStats.shareCount;
						this.info.UserId = res.data.userDetailsProjection.id;
						this.info.user_avatar = res.data.userDetailsProjection.avatar;
						this.info.user_nick_name = res.data.userDetailsProjection.user_nick_name;
						this.info.id = res.data.post.id;
						this.info.business_id = res.data.post.business_id;
						this.info.topic_id = res.data.post.topic_id;
						this.info.location = res.data.post.business_name;
						this.info.topic = res.data.post.topic_name;
						this.info.create_time = res.data.post.create_time;
						// console.log(this.info);
					},
					fail: (err) => {
						console.error('请求失败', err);
					}
				});
				uni.request({
					url: `http://127.0.0.1:8002/api/comment/post/${id}`,
					success: (res) => {
						this.comments = res.data
						this.info.commentCount = this.comments.length
					}
				})
			},

			doShare() {},
			doComment() {},
			follow() {
				this.info.isFollow = true
				uni.showToast({
					title: '关注成功'
				});
			},
			doLike(e) {
				let msg = e.type;
				if (msg) {
					this.info.like.likeCount--
					uni.showToast({
						title: '取消点赞成功'
					});
				} else {
					this.info.like.likeCount++
					uni.showToast({
						title: '点赞成功'
					});
				}
				uni.request({
					url: `http://127.0.0.1:8002/api/user-likes/${getApp().globalData.C_UserId}/post/${this.info.id}/toggle-like`,
					method: 'POST',
				})
				this.info.like.type = !this.info.like.type
			},
			doFavorite(e) {
				let msg = e.type;
				if (msg) {
					this.info.favorite.favoriteCount--
					uni.showToast({
						title: '取消收藏成功'
					});
				} else if (!msg) {
					this.info.favorite.favoriteCount++
					uni.showToast({
						title: '收藏成功'
					});
				}
				uni.request({
					url: `http://127.0.0.1:8002/api/user-favorite/${getApp().globalData.C_UserId}/post/${this.info.id}/toggle-favorite`,
					method: 'POST',
				})
				this.info.favorite.type = !this.info.favorite.type
			},
			preview(index) {
				uni.previewImage({
					current: index,
					urls: this.imagesList
				});
			},
			submit(text) {
				uni.request({
					url: "http://127.0.0.1:8002/api/comment/create",
					method: 'POST',
					data: {
						"userId": getApp().globalData.C_UserId,
						"postId": this.info.id,
						"topicId": this.info.topic_id,
						"content": text,
						"user_nick_name": getApp().globalData.C_UserNickName,
						"avatar": getApp().globalData.C_UserAvatar,
						"createTime": this.$formatTimestamp(this.currentTimeStamp),
					},
					success: (res) => {
						console.log(res.data);
						uni.showToast({
							title: '评论成功',
							icon: 'success',
							duration: 2000
						});
						uni.redirectTo({
							url: "/pages/detail/detail?id=" + this.info.id,
						});
					},
					fail: (err) => {
						console.error('请求失败', err);
					}
				})
				console.log(text)
			},
			deletePost() {
				uni.showModal({
					title: '提示',
					content: '确定要删除帖子吗？',
					success: (res) => {
						if (res.confirm) {
							uni.request({
								url: `http://127.0.0.1:8002/api/post/${this.info.id}`,
								method: 'DELETE',
								success: (res) => {
									console.log(res.data);
									uni.showToast({
										title: '删除成功',
										icon: 'success',
										duration: 2000,
									});
									uni.navigateBack({
										delta: 1
									})
								},
								fail: (err) => {
									console.error('删除失败', err);
								}
							})
						}
					}
				})

			},
			deleteComment(index) {
				uni.showModal({
					title: '提示',
					content: '确定要删除这条评论吗？',
					success: (res) => {
						if (res.confirm) {
							const commentId = this.comments[index].id; // 假设评论数据中有唯一的评论ID
							uni.request({
								url: `http://127.0.0.1:8002/api/comment/${commentId}`,
								method: 'DELETE',
								success: (res) => {
									console.log(res.data);
									uni.showToast({
										title: '删除评论成功',
										icon: 'success',
										duration: 2000,
									});
									// 从评论列表中移除删除的评论
									this.comments.splice(index, 1);
								},
								fail: (err) => {
									console.error('删除评论失败', err);
								}
							})
						}
					}
				});
			}
		}
	}
</script>

<style scoped>
	.selected-item {
		margin-top: 10px;
		padding: 5px 10px;
		background-color: #f5f5f5;
		border-radius: 5px;
	}

	.comment {
		display: flex;
		align-items: center;
		padding: 6px;
		border-bottom: 1px solid #eee;
	}

	.avatar {

		width: 48px;
		height: 48px;
		border-radius: 50%;
		margin-right: 12px;
	}

	.nickname {
		font-size: 16px;
		font-weight: bold;
		margin-bottom: 4px;
	}

	.time {
		font-size: 12px;
		color: #888;
	}

	.content {
		font-size: 14px;
		line-height: 1.5;
	}

	.delete-button {
		background-color: red;
		color: white;
		text-align: center;
		padding: 10px;
		margin-top: 10px;
		border-radius: 5px;
		cursor: pointer;
	}
</style>