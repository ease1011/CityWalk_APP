import App from './App'
import uView from 'uview-ui';

Vue.use(uView);
Vue.config.productionTip = false;
App.mpType = 'app';
// #ifndef VUE3
import Vue from 'vue'
import './uni.promisify.adaptor'
Vue.config.productionTip = false

import axios from "axios"; //引入axios
Vue.prototype.$axios = axios; //axios跟很多第三方模块不同的一点是它不能直接使用use方法，而是用这种方法
axios.defaults.baseURL = 'http://127.0.0.1:8002'; //默认接口地址  //自己本地服务器测试  调用接口地址127.0.0.1本地服务器  3001是端口

import AMapLoader from "@amap/amap-jsapi-loader";
Vue.use(AMapLoader);


// 引入全局组件
import divider from './components/common/divider.vue';
Vue.component('divider', divider)
import noThing from './components/common/no-thing.vue';
Vue.component('no-thing', noThing)

// 引入配置文件
import $C from './common/config.js'
Vue.prototype.$C = $C

import {
	formatTimestamp
} from './common/formatTimestamp.js';
Vue.prototype.$formatTimestamp = formatTimestamp;
// 挂载助手函数库
// import $U from './common/util.js'
// Vue.prototype.$U = $U


App.mpType = 'app'
const app = new Vue({
	...App
})
app.$mount()
// #endif

// #ifdef VUE3
import {
	createSSRApp
} from 'vue'
import AmapVueConfig from '@amap/amap-vue/lib/config';
AmapVueConfig.key = '0e51007383524fc65d80c31d50a02fc3';
export function createApp() {
	const app = createSSRApp(App)

	return {
		app,
		components: {
			Amap,
			AmapMarker,
		},
	}
}
// #endif