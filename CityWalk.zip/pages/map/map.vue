<template>
	<view class="map-container h-100">
		<view id="map" class="map"></view>
		<view class="flex-1">
			<view class="btn btn-outline-success mx-2" @click="createPlace"> 为此处标记</view>
			<view class="btn btn-outline-primary mx-1" @click="locateMe"> 定位我的</view>
			<!-- <view class="btn btn-outline-danger mx-2" @click="routePlan"> 到这去</view> -->
		</view>

		<view class="info-container">
			<view class="info-window">
				<p><text class="info-title">当前位置：</text>
					<text> {{currentLocation}} </text>
				</p>
			</view>
			<view class="info-window">
				<p><text class="info-title">当前天气：</text><text>{{weather}} </text> </p>
				<p class="float-end"><text class="info-title">当前风力：</text><text>{{windpower}} </text></p>
				<p><text class="info-title">当前风向：</text><text>{{winddirection}} </text></p>
				<p class="float-end"><text class="info-title">当前温度：</text><text>{{temperature}} </text></p>
				<p><text class="info-title">空气湿度：</text><text>{{humidity}} </text></p>
				<p><text class="info-title">更新时间：</text><text>{{reporttime}} </text> </p>
			</view>
			<!-- <view class="info-window">
				<p><text class="info-title">周围地点：</text>
					<view v-if="nearbyPlaces.length === 0" class="no-places">
						<text>附近没有地点信息</text>
					</view>
					<view v-else>
						<view v-for="(place, index) in nearbyPlaces" :key="index" class="place-item">
							<text>{{ place.name }}</text>
							<text class="distance">{{ place.distance.toFixed(2) }} 米</text>
						</view>
					</view>
				</p>
			</view> -->
		</view>
		<div id="panel" class="panel"></div>
	</view>
</template>

<script>
	// const key = "88fa2a2a3594560538ab5fa496863bac"
	export default {
		data() {
			return {
				currentLocation: '',
				newLocation: [],
				nowLocation: [],
				latestMarker: '',
				thisPosition: '',
				isModalVisible: false,
				nearbyPlaces: [],
				map: null,
				walkingRoute: null, // 用于存储步行路线数据
				adcode: "",
				weather: "",
				temperature: "",
				winddirection: "",
				windpower: "",
				humidity: "",
				reporttime: "",
				business: {
					id: '',
					name: '', //地点名称
					address: ',', //地址
					environment: '', //内部环境
					description: '', //店铺简介
					consumption: '', //消费情况
					services: '', //业务情况
					latitude: '31.2358', //店铺纬度
					longitude: '121.4777', //店铺经度
					imageUrls: '',
					overall_rating: '',
					taste_rating: '',
					service_rating: '',
					cleanliness_rating: '',
				}
			};
		},
		onLoad() {
			this.loadAMap();
			this.fetchBusinessData();
		},
		onShow() {
			this.locateMe();
			this.fetchBusinessData();
		},
		methods: {

			fetchBusinessData() {
				uni.request({
					url: 'http://127.0.0.1:8002/api/business/all',
					method: 'GET',
					success: (res) => {
						// console.log(res.data);
						this.business = res.data
						// console.log(this.business)
						this.addMarkers();
					},
					fail: (err) => {
						console.error(err);
					},
				})
			},
			loadAMap() {
				const that = this;
				if (typeof AMap === 'undefined') {
					const script = document.createElement('script');
					script.src =
						'https://webapi.amap.com/maps?v=1.4.15&key=0e51007383524fc65d80c31d50a02fc3&callback=initAMap';
					script.async = true;
					script.onerror = function() {
						console.error('加载高德地图失败');
					};
					window.initAMap = function() {
						that.initMap();
						that.addMarkers();
					};
					document.head.appendChild(script);
				} else {
					that.initMap();
					that.addMarkers();
				}
			},
			initMap() {
				let that = this;
				this.map = new AMap.Map("map", {
					zoom: 13,
					resizeEnable: true
				});
				// 定位到当前位置
				this.map.plugin('AMap.Geolocation', () => {
					const geolocation = new AMap.Geolocation({
						enableHighAccuracy: true,
						timeout: 10000,
					});
					this.map.addControl(geolocation);
					geolocation.getCurrentPosition((status, result) => {
						if (status == 'complete') {
							this.map.setCenter(result.position);
							this.map.add(new AMap.Marker({
								position: result.position
							}));
							uni.request({
								url: 'https://restapi.amap.com/v3/geocode/regeo?key=0e51007383524fc65d80c31d50a02fc3' +
									'&location=' + result.position.lng + ',' + result.position
									.lat + '&radius=1000&extensions=base&roadlevel=0',
								success(res) {
									that.currentLocation = res.data.regeocode.formatted_address;
									that.adcode = res.data.regeocode.addressComponent.adcode;
									uni.request({
										url: 'https://restapi.amap.com/v3/weather/weatherInfo?city=' +
											that.adcode +
											'&key=0e51007383524fc65d80c31d50a02fc3',
										success(res) {
											let lives = res.data.lives[0]
											that.weather = lives.weather
											that.temperature = lives.temperature
											that.winddirection = lives.winddirection
											that.windpower = lives.windpower
											that.humidity = lives.humidity
											that.reporttime = lives.reporttime
										}
									})
								},
								fail(err) {
									console.log(err);
								}
							})
						} else {
							console.error('定位失败');
						}
					});
				});
				this.map.on('click', (e) => {
					this.outputLngLat(e.lnglat);
				});
			},
			outputLngLat(lnglat) {
				if (this.latestMarker) {
					this.map.remove(this.latestMarker);
				}
				this.latestMarker = new AMap.Marker({
					position: lnglat,
					title: '新地点',
					icon: '//webapi.amap.com/images/marker_sprite.png',
				});
				this.map.add(this.latestMarker);
				this.thisPosition = lnglat
				console.log(this.thisPosition)
				this.newLocation.lat = lnglat.lat //定位目的地
				this.newLocation.lng = lnglat.lng
			},

			createPlace() {
				// 创建地点的逻辑
				console.log('创建地点按钮被点击');
				uni.navigateTo({
					url: "/pages/create-business/create-business?latitude=" + this.thisPosition.lat +
						"&longitude=" + this.thisPosition.lng
				})
				console.log("新建地点")
			},
			addMarkers() {
				let that = this;
				this.business.forEach((business) => {
					const marker = new AMap.Marker({
						position: new AMap.LngLat(business.longitude, business.latitude),
						// icon: '//a.amap.com/jsapi_demos/static/demo-center/icons/poi-marker-default.png',
						icon: '//webapi.amap.com/images/marker_sprite.png',
						offset: new AMap.Pixel(-13, -30),
					});
					this.map.add(marker);
					const infoWindowContent = `
					            <div class="info-window-content" style="background-color: rgba(255, 251, 203, 0.8);	padding: 10px;border-radius: 5px;box-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);max-width: 200px;">
					                <h3>${business.name}</h3>
					                <p><strong>地址:</strong> ${business.address}</p>
					                <p><strong>环境:</strong> ${business.environment}</p>
					                <p><strong>简介:</strong> ${business.description}</p>
					                <p><strong>消费:</strong> ${business.consumption}</p>
					                <p><strong>服务:</strong> ${business.services}</p>
									<p>提示：长按地点进入详情页~</p>
					            </div>
					        `;
					const infoWindow = new AMap.InfoWindow({
						isCustom: true,
						content: infoWindowContent,
						offset: new AMap.Pixel(16, -45)
					});
					marker.on('longpress', function(e) {
						// 在这里获取 business 的 id 并传递到详情页
						const businessId = business.id;
						uni.navigateTo({
							url: '/pages/business-detail/business-detail?id=' + businessId
						});
					});
					let isInfoWindowOpen = false;
					marker.on('click', function(e) {
						if (isInfoWindowOpen) {
							infoWindow.close();
							isInfoWindowOpen = false;
						} else {
							infoWindow.open(that.map, e.target.getPosition());
							isInfoWindowOpen = true;
						}
					})
				})
			},
			planWalkingRoute(start, end) {
				// 确保地图插件已加载
				this.map.plugin('AMap.Walking', () => {
					const walking = new AMap.Walking();
					// 异步获取步行路线
					walking.search(start, end, (status, result) => {
						if (status === 'complete' && result.info === 'OK') {
							// 步行路线获取成功，处理路线结果
							this.walkingRoute = result.route; // 存储步行路线数据
							this.displayWalkingRoute(result.route.paths); // 显示步行路线
						} else {
							// 步行路线获取失败，处理错误
							console.error('步行路线规划失败', status, result);
						}
					});
				});
			},
			displayWalkingRoute(paths) {
				// 移除已有的路线图层
				if (this.walkingRouteLayer) {
					this.map.remove(this.walkingRouteLayer);
				}
				// 创建新的路线图层并添加到地图上
				const polyline = new AMap.Polyline({
					path: paths,
					strokeColor: "#FF33FF",
					strokeWeight: 6,
					strokeOpacity: 0.2,
					isOutline: true,
					outlineColor: "white",
					zIndex: 0,
				});
				this.walkingRouteLayer = polyline;
				this.map.add(polyline);
			},
			routePlan() {
				if (this.nowLocation && this.newLocation) {
					console.log("当前", this.nowLocation, "要去", this.newLocation);
					this.planWalkingRoute(this.nowLocation, this.newLocation);
				} else {
					console.log("currentLocation: ", this.nowLocation, "latestMarker: ", this.latestMarker,
						"thisPosition: ", this.thisposition);
					console.log("当前", this.nowLocation, "要去", this.newLocation);
					console.error('当前位置或目的地位置未设置');
				}
			},

			locateMe() {
				if (this.map) {
					this.map.plugin('AMap.Geolocation', () => {
						const geolocation = new AMap.Geolocation({
							enableHighAccuracy: true,
							timeout: 100,
						});
						this.map.addControl(geolocation);
						geolocation.getCurrentPosition((status, result) => {
							if (status == 'complete') {
								this.map.setCenter(result.position);
								console.log('当前位置的经纬度是：', result.position);
								this.nowLocation.lat = result.position.lat
								this.nowLocation.lng = result.position.lng //定位当前位置
								this.thisPosition = result.position
							} else {
								console.error('定位失败');
							}
						});
					});
				}
			},
			updateCurrentLocation(position) {
				this.currentLocation = `当前位置：${position.lng}, ${position.lat}`;
			},
		},

	};
</script>

<style>
	@import url("../../common/map.css");

	.info-window-content {
		background-color: rgba(255, 252, 203, 0.5);
		padding: 10px;
		border-radius: 5px;
		box-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
		max-width: 200px;
	}

	.create-place-dialog {
		background-color: #fff;
		border: 1px solid #ccc;
		padding: 10px;
		border-radius: 5px;
		box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
		display: none;
	}

	.create-place-dialog button {
		margin-top: 10px;
		padding: 5px 10px;
		cursor: pointer;
	}
</style>