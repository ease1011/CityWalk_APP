<template>
	<view class="container">
		<view class="business-header">
			<view class="position-relative my-3">
				<image :src="business.imageUrls" mode="aspectFill" style="height: 350rpx;"
					class="w-100 border-1 shadow-lg">
				</image>
			</view>
			<text class=" font-md my-5 fw-bold ">{{ business.name}}</text>
		</view>

		<view class="divider"></view>

		<view class="business-info my-3">
			<view class="info-item">
				<view class="info-title">地址：</view>
				<view class="info-content">{{ business.address }}</view>
			</view>
			<view class="info-item">
				<view class="info-title">联系电话：</view>
				<view class="info-content">{{ business.phone_number }}</view>
			</view>
			<view class="info-item">
				<view class="info-title">营业时间：</view>
				<view class="info-content">{{ business.business_hours }}</view>
			</view>
			<view class="info-item">
				<view class="info-title">特别优惠：</view>
				<view class="info-content">{{ business.special_offers }}</view>
			</view>
		</view>

		<view class="divider"></view>
		<view class="info-item">
			<view class="info-title">详细信息：</view>
			<view class="info-content">{{ business.description }}</view>
		</view>
		<view class="divider"></view>
		<view class="business-ratings">
			<view class="rating-item">
				<view class="rating-title">综合评分：</view>
				<view class="rating-content">{{ rating.overall}}</view>
			</view>
			<view class="rating-item">
				<view class="rating-title">口味：</view>
				<view class="rating-content">{{ rating.taste}}</view>
			</view>
			<view class="rating-item">
				<view class="rating-title">服务：</view>
				<view class="rating-content">{{ rating.service }}</view>
			</view>
			<view class="rating-item">
				<view class="rating-title">清洁度：</view>
				<view class="rating-content">{{ rating.cleanliness}}</view>
			</view>
		</view>
		<view v-if="showRatingModal" class="rating-modal">
			<view class="form-item">
				<view class="form-label">综合评分：</view>
				<slider v-model="formRating.overall_rating" :min="0" :max="5" show-value activeColor="#FFCC33"
					backgroundColor="#F76260" block-color="#8A6DE9" block-size="20"
					@change="handleSliderChange('overall_rating', $event)" />
			</view>
			<view class="form-item">
				<view class="form-label">口味：</view>
				<slider v-model="formRating.taste_rating" :min="0" :max="5" show-value activeColor="#FFCC33"
					backgroundColor="#F76260" block-color="#8A6DE9" block-size="20"
					@change="handleSliderChange('taste_rating', $event)" />
			</view>
			<view class="form-item">
				<view class="form-label">服务：</view>
				<slider v-model="formRating.service_rating" :min="0" :max="5" show-value activeColor="#FFCC33"
					backgroundColor="#F76260" block-color="#8A6DE9" block-size="20"
					@change="handleSliderChange('service_rating', $event)" />
			</view>
			<view class="form-item">
				<view class="form-label">清洁度：</view>
				<slider v-model="formRating.cleanliness_rating" :min="0" :max="5" show-value activeColor="#FFCC33"
					backgroundColor="#F76260" block-color="#8A6DE9" block-size="20"
					@change="handleSliderChange('cleanliness_rating', $event)" />
			</view>
			<view class="btn btn-outline-success" @click="submitRating">提交评分</view>
			<view class="btn btn-outline-danger" @click="cancelRating">取消</view>
		</view>

		<view class="btn btn-success" @click="showRatingModal = true">我也打分</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				business: {},
				rating: {},
				formRating: {
					user_id: getApp().globalData.C_UserId,
					overall_rating: 0,
					taste_rating: 0,
					service_rating: 0,
					cleanliness_rating: 0,
					business_id: 0,
				},
				showRatingModal: false,
			};
		},
		onShow() {
			this.formRating.business_id = this.$route.query.id
			this.getBusinessInfo();
		},
		methods: {
			goRating() {
				this.showRatingModal = true;
			},
			handleSliderChange(key, event) {
				console.log('Slider value changed:', event.detail.value);
				this.formRating[key] = event.detail.value;
			},
			getBusinessInfo() {
				// 发起 API 请求，获取商家信息
				uni.request({
					url: 'http://127.0.0.1:8002/api/business/id/' + this.formRating.business_id,
					success: (res) => {
						console.log(res.data);
						this.business = res.data[0];
					},
					fail: (err) => {
						console.error('获取商家信息失败', err);
					}
				});
				uni.request({
					url: 'http://127.0.0.1:8002/api/user/averageRatings/' + this.formRating.business_id,
					success: (res) => {
						console.log(res.data);
						this.rating = res.data;
					}
				})
			},
			submitRating() {
				uni.request({
					url: 'http://127.0.0.1:8002/api/user/create/userBusinessRating',
					method: 'POST',
					data: this.formRating,
					success: (res) => {
						console.log('新增成功', res.data);
						uni.showToast({
							title: '提交成功!',
						})
						// 提交成功后关闭弹窗
						this.showRatingModal = false;
					},
					fail: (err) => {
						console.error('新增失败', err);
					},
				})
			},

			cancelRating() {
				// 清空输入的评分
				this.formRating.taste_rating = 0;
				this.formRating.service_rating = 0;
				this.formRating.cleanliness_rating = 0;
				this.showRatingModal = false;
			},
		}
	};
</script>

<style scoped>
	.container {
		padding: 20rpx;
	}

	.business-header {
		text-align: center;
		margin-bottom: 20rpx;
	}

	.business-image {
		width: 200rpx;
		height: 200rpx;
		border-radius: 10rpx;
		margin-bottom: 10rpx;
	}

	.business-description {
		color: #666;
		margin-bottom: 20rpx;
	}

	.divider {
		height: 1px;
		background-color: #eee;
		margin: 20rpx 0;
	}

	.business-info {
		margin-bottom: 20rpx;
	}

	.info-item {
		display: flex;
		align-items: center;
		margin-bottom: 10rpx;
	}

	.info-title {
		width: 160rpx;
		font-weight: bold;
	}

	.info-content {
		flex: 1;
		color: #333;
	}

	.business-ratings {
		display: flex;
		justify-content: space-between;
	}

	.rating-item {
		text-align: center;
		flex: 1;
		padding: 10rpx;
		border-radius: 8rpx;
		background-color: #f8f8f8;
	}

	.rating-title {
		font-weight: bold;
		color: #333;
	}

	.rating-content {
		color: #f00;
	}

	.rating-modal {
		position: fixed;
		width: 220px;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		background-color: #fff;
		padding: 40rpx;
		margin-bottom: 40px;
		border-radius: 10rpx;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
		z-index: 1000;
	}

	.rating-input {
		display: flex;
		align-items: center;
		margin-bottom: 10rpx;
	}

	.rating-input view {
		width: 80rpx;
		font-weight: bold;
	}

	.rating-input input {
		flex: 1;
		padding: 8rpx;
		border: 1px solid #ccc;
		border-radius: 5rpx;
	}

	.btn-cancel {
		margin-top: 10rpx;
		color: #666;
		text-align: center;
		cursor: pointer;
	}
</style>