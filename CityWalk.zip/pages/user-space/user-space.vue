<template>
	<view class="profile">
		<!-- 头部信息 -->
		<view class="profile-header">
			<!-- 背景图片 + 头像 + 用户名 + 编辑按钮-->
			<img class="profile-bg" :src="User.backgroundImage" alt="Background Image">
			<img class="profile-avatar" :src="User.avatar" alt="Avatar">
			<view class="profile-user_nick_name">{{ User.user_nick_name }}</view>
			<view class="profile-bio">{{ User.bio }}</view>
			<view class="profile-info">
				<view class="info-item">关注: <text>{{ User.followingCount }}</text></view>
				<view class="info-item">粉丝: <text>{{ User.followersCount }}</text></view>
				<view class="info-item">城市: <text>{{ User.city }}</text></view>
			</view>

			<button class="btn profile-edit-btn mx-2" @click="toggleFollow"
				:class="isFollowing? 'btn-danger' :'btn-primary'">
				{{ isFollowing ? '取消关注' : '关注' }}
			</button>
			<!-- 		<button class="btn profile-edit-btn mx-2" @click="gotoChat">
				<text class="iconfont icon-news-filling"></text>聊天</button> -->
		</view>

		<!-- 主要内容区域 -->
		<view class="container" :style="{ height: swiperHeight + 'px' }">
			<!-- 选项卡 -->
			<view class="profile-tabs">
				<view class="profile-tab" v-for="(tab, index) in tabs" :key="index" @click="changeTab(index)"
					:class="{ 'active': activeTabIndex === index }">{{ tab.title }}
					<text class="font-sm text-secondary p-2"> {{ tab.num }}</text>
				</view>
			</view>
			<!-- 内容 -->
			<view class="profile-posts">
				<view class="profile-post" v-for="post in TabPosts" :key="post.id" @click="openDetail(post)">
					<img :src="post.imageUrl" alt="Post Image">
					<view class="post-description p-2 mb-2">{{ post.description }}</view>
					<view class="border-bottom"></view>
				</view>
				<!-- 如果没有笔记数据，则显示提示 -->
				<view v-if="TabPosts.length === 0" class="no-posts">
					暂无笔记
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				User: {
					userId: '',
					user_nick_name: "",
					avatar: "",
					backgroundImage: "",
					bio: "",
					city: "",
					followersCount: 0,
					followingCount: 0,
					posts: [],
				},
				tabs: [{
					title: "笔记",
					posts: [],
					num: 0,
				}, ],
				activeTabIndex: 0,
				swiperHeight: 0,
				isFollowing: false // 添加关注状态变量
			};
		},
		computed: {
			TabPosts() {
				return this.tabs[this.activeTabIndex].posts;
			},
		},
		methods: {
			openDetail(post) {
				uni.navigateTo({
					url: "/pages/detail/detail?id=" + post.id,
				})
			},
			gotoChat() {
				uni.navigateTo({
					url: "/pages/user-chat/user-chat?id=" + getApp().globalData.C_UserId + "?userBid=" + this.User
						.userId,
				})
			},
			toggleFollow() { //关注和取关
				uni.request({
					url: `http://127.0.0.1:8002/api/friendship/${getApp().globalData.C_UserId}/follower/${this.User.userId}/toggle-follow`,
					method: 'POST',
				})
				if (this.isFollowing) {
					this.follow(!this.isFollowing);
				} else {
					this.follow(!this.isFollowing);
				}
			},
			follow(following) {
				if (following) {
					uni.showToast({
						icon: 'none',
						title: "关注成功",
					});
				} else {
					uni.showToast({
						icon: 'none',
						title: "取消关注成功",
					});
				}
				this.isFollowing = following; // 更新关注状态
			},
			changeTab(index) {
				this.activeTabIndex = index;
			},
			updatePosts(posts) {
				this.tabs[0].posts = posts.map(post => ({
					id: post.id,
					imageUrl: JSON.parse(post.image_url)[0],
					description: post.description,
				}));
				this.tabs[0].num = posts.length; // 更新笔记数量
			},
			fetchUserPosts(userId) {
				let url = `http://127.0.0.1:8002/api/post/${userId}/user/post`;
				fetch(url)
					.then((response) => response.json())
					.then((data) => {
						this.updatePosts(data);
					})
					.catch((error) => {
						console.error("Error fetching user posts:", error);
					});
			},
			fetchUserData(userId) {
				let url = `http://127.0.0.1:8002/api/user/${userId}/details`;
				fetch(url)
					.then((response) => response.json())
					.then((data) => {
						this.User = {
							userId: data.id,
							user_nick_name: data.user_nick_name,
							avatar: data.avatar,
							backgroundImage: data.background_image,
							bio: data.bio,
							city: data.city,
							followersCount: data.followersCount,
							followingCount: data.followingCount,
							posts: [],
						};
						// 获取用户笔记数据
						this.fetchUserPosts(userId);
					})
					.catch((error) => {
						console.error("Error fetching user data:", error);
					});

				uni.request({
					url: `http://127.0.0.1:8002/api/friendship/${getApp().globalData.C_UserId}/user/${userId}/follower`,
					method: 'GET',
					success: (res) => {
						this.isFollowing = res.data
					}
				})
			},
		},
		mounted() {
			this.swiperHeight = document.documentElement.clientHeight + 40; // 根据设计调整高度
		},
		watch: {
			User: {
				handler() {
					this.updatePosts();
				},
				deep: true,
			},
		},
		created() {
			const userId = this.$route.query.id || 5; // 如果没有传入userId，默认为5
			this.fetchUserData(userId);
		},
	};
</script>

<style lang="scss" scoped>
	.profile {
		.profile-header {
			position: relative;
			text-align: center;

			.profile-bg {
				width: 100%;
				max-height: 200px;
				object-fit: cover;
			}

			.profile-avatar {
				width: 120px;
				height: 120px;
				border-radius: 50%;
				margin: -60px auto 20px;
				border: 3px solid #fff;
				box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
			}

			.profile-user_nick_name {
				font-size: 24px;
				font-weight: bold;
				color: #333;
			}

			.profile-bio {
				margin-top: 10px;
				color: #666;
			}

			.profile-info {
				display: flex;
				justify-content: center;
				margin-top: 10px;

				.info-item {
					margin-right: 20px;
					color: #666;
					font-size: 14px;

					&:last-child {
						margin-right: 0;
					}

					text {
						font-weight: bold;
						margin-left: 5px;
					}
				}
			}

			.profile-edit-btn {
				margin-top: 10px;
			}
		}

		.container {
			padding: 10px;
		}

		.profile-tabs {
			display: flex;
			justify-content: space-around;
			background-color: #f9f9f9;
			padding: 10px 0;

			.profile-tab {
				padding: 10px;
				cursor: pointer;
				color: #666;
				font-weight: bold;
				border-bottom: 2px solid transparent;
				transition: border-color 0.3s;

				&.active {
					color: #333;
					border-bottom-color: #333;
				}
			}
		}

		.profile-posts {
			margin-top: 20px;

			.profile-post {
				margin-bottom: 20px;

				img {
					width: 100%;
					border-radius: 5px;
				}

				.post-description {
					margin-top: 10px;
				}
			}

			.no-posts {
				text-align: center;
				color: #666;
				margin-top: 20px;
			}
		}
	}
</style>