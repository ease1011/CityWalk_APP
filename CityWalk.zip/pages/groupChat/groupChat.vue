<template>
	<view class="chat-room">
		<!-- 聊天消息列表 -->
		<view class="py-5 h-100">
			<scroll-view class="message-list uni-scroll-view scroll-view" scroll-y ref="messageList">
				<view v-for="(message, index) in messages" :key="index" class="message">
					<!-- 显示用户头像和昵称和时间 -->
					<view class="message-header flex align-center">
						<image :src="message.userAvatar" class="user-avatar " mode="aspectFill"
							@click="openSpace(message.groupChat.userId)" />
						<text class="user-nickname">{{ message.userNickname }}</text>
					</view>
					<view v-if="message.groupChat.messageType === 'text'" class="text-message">
						{{ message.groupChat.content }}
					</view>
					<image v-else-if="message.groupChat.messageType === 'image'" :src="message.groupChat.content"
						class="image-message" mode="aspectFit" @click="previewImage(message.groupChat.content)" />
					<video v-else-if="message.groupChat.messageType === 'video'" :src="message.groupChat.content"
						class="video-message" controls />
					<p class="message-time">{{ message.groupChat.createTime }}</p>
				</view>
			</scroll-view>
		</view>

		<!-- 底部发送消息区域 -->
		<view class="bottom-bar">
			<!-- 发送文本消息 -->
			<input v-model="textMessage" placeholder="输入消息" type="text" class="message-input" />
			<!-- 发送图片消息 -->
			<button @click="chooseImage">
				<text class="iconfont icon-tupian1 text-main"></text>
			</button>
			<!-- 发送视频消息 -->
			<button @click="chooseVideo">
				<text class="iconfont icon-play"></text>
			</button>
			<button @click="sendMessage" class="send-button">发送</button>
		</view>
	</view>
</template>

<script>
	export default {
		onShow() {
			this.topic_id = this.$route.query.id;
			this.uploadMessage.topicId = this.topic_id; // 在onShow中设置topicId
			this.uploadMessage.createTime = this.$formatTimestamp(this.currentTimeStamp); // 在onShow中设置createTime
			this.getMessages();
		},

		data() {
			return {
				topic_id: 0,
				group_id: 0,
				messages: [],
				textMessage: '', // 保存用户输入的文本消息内容
				selectedImage: '', // 保存用户选择的图片文件路径
				selectedVideo: '', // 保存用户选择的视频文件路径
				currentTimeStamp: new Date().getTime(),
				uploadMessage: {
					topicId: null, // 初始化为null
					userId: getApp().globalData.C_UserId,
					createTime: null, // 初始化为null
					content: '',
					messageType: '',
				},
			};
		},
		methods: {
			openSpace(id) {
				console.log(id)
				console.log(this.messages)
				if (id === getApp().globalData.C_UserId) {
					uni.switchTab({
						url: '/pages/mine/mine'
					})
				} else {
					uni.navigateTo({
						url: "/pages/user-space/user-space?id=" + id
					});
				}
				console.log('打开个人空间', id)
			},
			getMessages() {
				uni.request({
					url: `http://127.0.0.1:8002/api/groupchat/${this.topic_id}`,
					method: 'GET',
					success: (res) => {
						console.log(res);
						// 清空原有的消息数组
						this.messages.splice(0, this.messages.length);
						// 将接口返回的数据添加到消息数组中
						for (let i = 0; i < res.data.length; i++) {
							this.messages.push(res.data[i]);
						}
						console.log(this.messages);
					}
				});
			},
			chooseImage() {
				uni.chooseImage({
					count: 1, // 最多选择一张图片
					sizeType: ['compressed'], // 压缩图片
					sourceType: ['album', 'camera'], // 选择图片的来源，相册或相机
					success: (res) => {
						this.uploadMessage.content = res.tempFilePaths[0];
						uni.uploadFile({
							url: 'http://127.0.0.1:8002/upload/groupChatImage',
							filePath: res.tempFilePaths[0],
							name: 'file',
							success: (uploadFileRes) => {
								console.log('上传成功', uploadFileRes.data);
								this.uploadMessage.messageType = "image"
								this.uploadMessage.content = uploadFileRes.data
								uni.request({
									url: `http://127.0.0.1:8002/api/groupchat/${this.topic_id}`,
									method: 'POST',
									data: this.uploadMessage,
									success: (res) => {
										console.log('发送消息成功', res.data);
										console.log(this.uploadMessage);
										// 将新消息添加到消息数组中
										this.getMessages()
										// 滚动到底部
										this.scrollToBottom();
									},
									fail: (err) => {
										console.error('发送消息失败', err);
									},
								});
							},
							fail: (err) => {
								console.error('上传失败', err);
							}
						});
					},
					fail: (err) => {
						console.error('选择图片失败', err);
					},
				});
			},
			// 选择视频
			chooseVideo() {
				uni.chooseVideo({
					sourceType: ['album', 'camera'], // 选择视频的来源，相册或相机
					maxDuration: 60, // 视频最长时长，单位秒
					success: (res) => {
						this.uploadMessage.content = res.tempFilePath;
						uni.uploadFile({
							url: 'http://127.0.0.1:8002/upload/groupChatVideo',
							filePath: res.tempFilePath,
							name: 'file',
							success: (uploadFileRes) => {
								console.log('上传成功', uploadFileRes.data);
								this.uploadMessage.messageType = "video"
								this.uploadMessage.content = uploadFileRes.data
								uni.request({
									url: `http://127.0.0.1:8002/api/groupchat/${this.topic_id}`,
									method: 'POST',
									data: this.uploadMessage,
									success: (res) => {
										console.log('发送消息成功', res.data);
										console.log(this.uploadMessage);
										// 将新消息添加到消息数组中
										this.getMessages()
										this.scrollToBottom();
									},
									fail: (err) => {
										console.error('发送消息失败', err);
									},
								});
							},
							fail: (err) => {
								console.error('上传失败', err);
							}
						});
					},

					fail: (err) => {
						console.error('选择视频失败', err);
					},
				});
			},
			sendMessage() {
				this.uploadMessage.messageType = 'text'
				this.uploadMessage.content = this.textMessage.trim()
				this.textMessage = '';
				uni.request({
					url: `http://127.0.0.1:8002/api/groupchat/${this.topic_id}`,
					method: 'POST',
					data: this.uploadMessage,
					success: (res) => {
						console.log('发送消息成功', res.data);
						console.log(this.uploadMessage);
						// 将新消息添加到消息数组中
						this.getMessages()
						// 滚动到底部
						this.scrollToBottom();
					},
					fail: (err) => {
						console.error('发送消息失败', err);
					},
				});
			},

			// 滚动到底部
			scrollToBottom() {
				uni.createSelectorQuery().in(this).select('.scroll-view').scrollOffset((rect) => {
					if (rect) {
						const scrollTop = rect.height + rect.scrollTop;
						uni.pageScrollTo({
							scrollTop: scrollTop,
						});
					}
				}).exec();
			},
			// 预览图片
			previewImage(url) {
				uni.previewImage({
					urls: [url],
				});
			},
		},
	};
</script>

<style scoped>
	.chat-room {
		display: flex;
		flex-direction: column;
		height: 100vh;
	}

	.message-list {
		flex: 1;
		padding: 10px;
		overflow-y: scroll;
	}

	.message {
		margin-bottom: 10px;
		padding: 10px;
		border-radius: 15px;
		background-color: #e6f7ff;
		max-width: 90%;
	}

	.text-message {
		color: black;
	}

	.image-message,
	.video-message {
		width: 100%;
		max-width: 300px;
		border-radius: 10px;
	}

	.bottom-bar {
		display: flex;
		align-items: center;
		padding: 10px;
		background-color: #fff;
		box-shadow: 0 -1px 5px rgba(0, 0, 0, 0.1);
		position: fixed;
		height: 70px;
		font-size: 16px;
		bottom: 0;
		width: 100%;
	}

	.message-input {
		flex: 1;
		padding: 5px;
		border: 1px solid #ccc;
		border-radius: 5px;
		margin-right: 10px;
		height: 35px;
	}

	.send-button {
		padding: 5px 10px;
		border-radius: 5px;
		background-color: #007bff;
		color: #fff;
		border: none;
		cursor: pointer;
	}

	.send-button:active {
		background-color: #0056b3;
	}

	.send-button:focus {
		outline: none;
	}

	.user-avatar {
		width: 45px;
		height: 45px;
		border-radius: 50%;
		margin-right: 8px;
		margin-bottom: 4px;
	}

	.user-nickname {
		font-weight: bold;
		font-size: 16px;
		margin-right: 8px;
	}

	.message-time {
		font-size: 12px;
		color: darkgray;
		line-height: 45px;
	}
</style>