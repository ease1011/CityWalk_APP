<template>
	<view class="chat-room">
		<!-- 聊天消息列表 -->
		<view class="py-5 h-100">
			<scroll-view class="message-list uni-scroll-view scroll-view" scroll-y ref="messageList">
				<view v-for="(message, index) in messages" :key="index" class="message">
					<!-- 显示用户头像和昵称 -->
					<view class="message-header">
						<image :src="message.avatar" class="user-avatar" mode="aspectFill" />
						<text class="user-nickname">{{ message.nickname }}</text>
					</view>
					<view v-if="message.type === 'text'" class="text-message">{{ message.content }}</view>
					<image v-else-if="message.type === 'image'" :src="message.content" class="image-message"
						mode="aspectFit" @click="previewImage(message.content)" />
					<video v-else-if="message.type === 'video'" :src="message.content" class="video-message" controls />
					<view v-else-if="message.type === 'location'" class="location-message">
						<text>{{ message.content }}</text>
					</view>
				</view>
			</scroll-view>
		</view>

		<!-- 清除按钮 -->
		<view class="clear-button" @click="clearMessages">清除</view>

		<!-- 底部发送消息区域 -->
		<view class="bottom-bar">
			<!-- 发送文本消息 -->
			<input v-model="textMessage" placeholder="输入消息" type="text" class="message-input" />
			<!-- 发送图片消息 -->
			<button @click="chooseImage">
				<text class="iconfont icon-tupian1 text-main"></text>
			</button>
			<!-- 发送视频消息 -->
			<button @click="chooseVideo">
				<text class="iconfont icon-play"></text>
			</button>
			<!-- 发送位置消息 -->
			<button @click="sendLocation">
				<text class="iconfont icon-navigation"></text>
			</button>
			<button @click="sendMessage" class="send-button">发送</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				messages: JSON.parse(localStorage.getItem('chatMessages')) || [{
						type: 'text',
						content: '你好',
						avatar: '/static/logo.png',
						nickname: 'citywalk'
					},
					{
						type: 'text',
						content: 'Hello',
						avatar: '/static/logo.png',
						nickname: 'citywalk'
					},
					{
						type: 'text',
						content: 'How are you?',
						avatar: '/static/logo.png',
						nickname: 'citywalk'
					},
				],
				textMessage: '', // 输入的文本消息
			};
		},
		methods: {
			// 保存聊天记录到本地存储
			saveMessagesToLocal() {
				localStorage.setItem('chatMessages', JSON.stringify(this.messages));
			},
			// 清除聊天记录
			clearMessages() {
				localStorage.removeItem('chatMessages');
				this.messages = [];
			},
			// 发送文本消息
			sendMessage() {
				if (this.textMessage.trim() !== '') {
					this.messages.push({
						type: 'text',
						content: this.textMessage.trim(),
						avatar: '/static/logo.png',
						nickname: 'citywalk',
					});
					this.saveMessagesToLocal(); // 保存聊天记录到本地存储
					this.textMessage = ''; // 清空输入框
					this.$nextTick(() => {
						this.scrollToBottom();
					});
				}
			},
			// 选择图片并发送
			async chooseImage() {
				try {
					const res = await uni.chooseImage({
						count: 1,
						sizeType: ['compressed'],
						sourceType: ['album', 'camera'],
					});
					const imageUrl = res.tempFilePaths[0];
					this.messages.push({
						type: 'image',
						content: imageUrl,
						avatar: '/static/logo.png',
						nickname: 'citywalk',
					});
					this.saveMessagesToLocal(); // 保存聊天记录到本地存储
					this.$nextTick(() => {
						this.scrollToBottom();
					});
				} catch (error) {
					console.error(error);
				}
			},
			// 选择视频并发送
			async chooseVideo() {
				try {
					const res = await uni.chooseVideo({
						sourceType: ['album', 'camera'],
					});
					const videoUrl = res.tempFilePath;
					this.messages.push({
						type: 'video',
						content: videoUrl,
						avatar: '/static/logo.png',
						nickname: 'citywalk',
					});
					this.saveMessagesToLocal(); // 保存聊天记录到本地存储
					this.$nextTick(() => {
						this.scrollToBottom();
					});
				} catch (error) {
					console.error(error);
				}
			},
			// 发送位置消息
			sendLocation() {
				uni.getLocation({
					type: 'gcj02',
					success: (res) => {
						const latitude = res.latitude;
						const longitude = res.longitude;
						const address = '用户当前位置';
						this.messages.push({
							type: 'location',
							content: address,
							latitude: latitude,
							longitude: longitude,
							avatar: '/static/logo.png',
							nickname: 'citywalk',
						});
						this.saveMessagesToLocal(); // 保存聊天记录到本地存储
						this.$nextTick(() => {
							this.scrollToBottom();
						});
					},
					fail: (error) => {
						console.error('获取位置失败', error);
					}
				});
			},
			// 滚动到底部
			scrollToBottom() {
				uni.createSelectorQuery().in(this).select('.scroll-view').scrollOffset((rect) => {
					if (rect) {
						const scrollTop = rect.height + rect.scrollTop;
						uni.pageScrollTo({
							scrollTop: scrollTop,
						});
					}
				}).exec();
			},
			// 预览图片
			previewImage(url) {
				uni.previewImage({
					urls: [url],
				});
			},
		},
	};
</script>

<style scoped>
	.chat-room {
		display: flex;
		flex-direction: column;
		height: 100vh;
	}

	.message-list {
		flex: 1;
		padding: 10px;
		overflow-y: scroll;
	}

	.message {
		margin-bottom: 10px;
		padding: 10px;
		border-radius: 15px;
		/* 圆角更大 */
		background-color: #e6f7ff;
		/* 淡蓝色背景 */
		max-width: 80%;
		/* 控制消息宽度 */
	}

	.text-message {
		color: black;
	}

	.image-message,
	.video-message {
		width: 100%;
		max-width: 300px;
		border-radius: 10px;
	}

	.location-message {
		padding: 5px;
		border: 1px solid #ccc;
		border-radius: 5px;
	}

	.bottom-bar {
		display: flex;
		align-items: center;
		padding: 10px;
		background-color: #fff;
		box-shadow: 0 -1px 5px rgba(0, 0, 0, 0.1);
		position: fixed;
		height: 70px;
		font-size: 16px;
		bottom: 0;
		width: 100%;
	}

	.message-input {
		flex: 1;
		padding: 5px;
		border: 1px solid #ccc;
		border-radius: 5px;
		margin-right: 10px;
		height: 35px;
	}

	.send-button {
		padding: 5px 10px;
		border-radius: 5px;
		background-color: #007bff;
		color: #fff;
		border: none;
		cursor: pointer;
	}

	.send-button:active {
		background-color: #0056b3;
	}

	.send-button:focus {
		outline: none;
	}

	.user-avatar {
		width: 30px;
		height: 30px;
		border-radius: 50%;
		margin-right: 8px;
	}

	.user-nickname {
		font-weight: bold;
		font-size: 14px;
	}

	.clear-button {
		position: absolute;
		top: 10px;
		right: 10px;
		padding: 5px 10px;
		border-radius: 5px;
		background-color: #dc3545;
		color: #fff;
		cursor: pointer;
	}
</style>