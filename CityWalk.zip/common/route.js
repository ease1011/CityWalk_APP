import Vue from 'vue';
import Router from 'vue-router';
import MapPage from '@/components/MapPage.vue';
import GroupChat from '@/pages/groupChat/groupChat.vue';

Vue.use(Router);

export default new Router({
	routes: [{
			path: '/',
			name: 'MapPage',
			component: MapPage
		},
		{
			path: '/groupChat',
			name: 'GroupChat', // 这里是路由名称
			component: GroupChat
		},
	]
});