<template>
	<view>
		<topic-info :info="info"></topic-info>
		<divider></divider>
		<view class="flex align-center justify-content-around mb-2 text-main ">
			<view class="mr-5 btn btn-primary" @click="goToGroupChat"> 进入群聊</view>
			<view class="ml-5 btn text-main  " @click="doTopicFavorite"
				:class="{ ' btn-success text-white': favorite.type }">
				<text class=" iconfont icon-shoucang font-lg "></text>
				<text :class="{ 'font-md': favorite.type }">
					<span v-if="favorite.type">已收藏</span>
					<span v-else>点击收藏</span>
					{{ this.favorite.count }}
				</text>
			</view>
		</view>

		<divider></divider>
		<!-- tab -->
		<!-- 列表 -->
		<template v-if="list.length > 0">
			<block v-for="(item,index) in list" :key="index">
				<common-list :item="item" :index="index" @follow="follow" @doLike="doLike"
					@doFavorite="doFavorite"></common-list>
				<divider></divider>
			</block>
		</template>
		<template v-else>
			<no-thing></no-thing>
		</template>

	</view>
</template>

<script>
	import topicInfo from '@/components/topic-detail/topic-info.vue';
	import commonList from '@/components/common/common-list.vue';
	import noThing from '@/components/common/no-thing.vue';

	export default {
		components: {
			topicInfo,
			commonList,
			noThing,
		},
		data() {
			return {
				info: {
					coverImage: "",
					description: "",
					title: "",
					posts_count: 1,
					today_count: 1,
					news_count: 1,
				},
				hotList: [{
					title: "【今日话题】一起去CityWalk吧~"
				}, {
					title: "想要去CityWalk"
				}],
				favorite: {
					type: false,
					count: 11,
				},
				tabIndex: 0,
				list: [],
			};
		},
		computed: {
			loadtext() {
				return this.loadtext;
			},
		},
		onLoad() {
			const topicId = this.$route.query.id;
			this.topicId = topicId
			this.getData(topicId);
		},

		methods: {
			goToGroupChat() {
				console.log('跳转到群聊页面');
				uni.navigateTo({
					url: "/pages/groupChat/groupChat?id=" + this.topicId
				})
			},
			getData(topicId) {
				uni.request({
					url: `http://127.0.0.1:8002/api/user-topic-favorite/topic/${this.topicId}/favorites-count`,
					method: 'GET',
					success: (res) => {
						this.favorite.count = res.data
					}
				})
				uni.request({
					url: `http://127.0.0.1:8002/api/user-topic-favorite/${getApp().globalData.C_UserId}/topic/${this.topicId}/favorite`,
					method: 'GET',
					success: (res) => {
						this.favorite.type = res.data
					}

				})
				uni.request({
					url: "http://127.0.0.1:8002/api/topic/" + topicId,
					success: (res) => {
						this.info.coverImage = res.data.coverImage
						this.info.title = res.data.title
						this.info.description = res.data.description
					},
					fail: (err) => {
						console.error(err);
					}
				});
				uni.request({
					url: "http://127.0.0.1:8002/api/topic/" + topicId + "/posts/details",
					success: (res) => {
						console.log(res.data)
						this.info.posts_count = res.data.length
						for (let i = 0; i < res.data.length; i++) {
							let imageUrlArray = JSON.parse(res.data[i].post.image_url);
							let newData = {
								PostId: res.data[i].post.id,
								UserId: res.data[i].user.id,
								user_nick_name: res.data[i].user.user_nick_name,
								user_avatar: res.data[i].user.avatar,
								create_time: res.data[i].post.create_time,
								isFollow: true,
								description: res.data[i].post.description,
								image_url: res.data[i].post.image_url,
								image_url: imageUrlArray[0],
								like: {
									likeCount: res.data[i].postStats.likeCount,
								},
								favorite: {
									favoriteCount: res.data[i].postStats.favoriteCount,
								},
								commentCount: 0,
								shareCount: res.data[i].postStats.shareCount,
							};
							uni.request({
								url: 'http://127.0.0.1:8002/api/comment/post/' + res.data[i].post.id,
								success: (res) => {
									this.comments = res.data
									newData.commentCount = this.comments.length
								}
							});
							uni.request({
								url: 'http://127.0.0.1:8002/api/user-likes/' +
									getApp().globalData.C_UserId +
									'/post/' + res.data[i].post.id +
									'/likes',
								method: 'GET',
								success: (res) => {
									newData.like.type = res.data
								}
							}); //获取收藏状态
							uni.request({
								url: 'http://127.0.0.1:8002/api/user-favorite/' +
									getApp().globalData.C_UserId +
									'/post/' + res.data[i].post.id +
									'/favorite',
								method: 'GET',
								success: (res) => {
									newData.favorite.type = res.data
								}
							});
							this.list.push(newData)
						}
					}
				})
			},
			doLike(e) {
				const index = e.index
				const type = !this.list[index].like.type;
				const psid = this.list[index].PostId
				const urid = getApp().globalData.C_UserId
				if (type) {
					this.list[index].like.likeCount++;
					this.list[index].like.type = true;
					uni.showToast({
						title: '点赞成功'
					});
				} else {
					if (this.list[index].like.likeCount > 0) {
						this.list[index].like.likeCount--;
					}
					this.list[index].like.type = false;
					uni.showToast({
						title: '取消点赞成功'
					});
				}
				uni.request({
					url: `http://127.0.0.1:8002/api/user-likes/${urid}/post/${psid}/toggle-like`,
					method: 'POST',
				})
			},
			doFavorite(e) {
				const index = e.index
				const type = !this.list[index].favorite.type;
				const psid = this.list[index].PostId
				const urid = getApp().globalData.C_UserId
				if (type) {
					this.list[index].favorite.favoriteCount++;
					this.list[index].favorite.type = true;
					uni.showToast({
						title: '收藏成功'
					});
				} else {
					if (this.list[index].favorite.favoriteCount > 0) {
						this.list[index].favorite.favoriteCount--;
					}
					this.list[index].favorite.type = false;
					uni.showToast({
						title: '取消收藏成功'
					});
				}
				uni.request({
					url: `http://127.0.0.1:8002/api/user-favorite/${urid}/post/${psid}/toggle-favorite`,
					method: 'POST',
				})
			},
			doTopicFavorite() {

				let item = this.favorite;
				if (item.type) {
					item.count--;
					uni.showToast({
						title: '取消收藏成功',
					});
				} else {
					item.count++;
					uni.showToast({
						title: '收藏成功'
					});
				}
				uni.request({
					url: `http://127.0.0.1:8002/api/user-topic-favorite/${getApp().globalData.C_UserId}/utf/${this.topicId}/toggle-favorite`,
					method: 'POST',
				})
				this.favorite.type = !this.favorite.type;
				console.log(item.type);

			},
			// tab切换
			changeTab(index) {
				this.tabIndex = index;
			},
		},
	};
</script>

<style>
</style>