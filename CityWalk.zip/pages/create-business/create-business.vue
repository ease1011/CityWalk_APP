<template>
	<view class="container">
		<view class="form-item">
			<view class="form-label">名称：</view>
			<input class="h-100" v-model="formData.name" placeholder="请输入名称" />
		</view>
		<view class="form-item">
			<view class="form-label">地址：</view>
			<input class="h-100" v-model="formData.address" placeholder="请输入地址" />
		</view>
		<view class="form-item">
			<view class="form-label">环境：</view>
			<input class="h-100" v-model="formData.environment" placeholder="环境情况" />
		</view>
		<view class="form-item">
			<view class="form-label">消费：</view>
			<input class="h-100" v-model="formData.consumption" placeholder="消费情况" />
		</view>
		<view class="form-item">
			<view class="form-label">服务：</view>
			<input class="h-100" v-model="formData.services" placeholder="服务情况" />
		</view>

		<view class="form-item">
			<view class="form-label">图片：</view>
			<view v-if="formData.imageUrls">
				<image :src="formData.imageUrls" mode="aspectFill" style="height: 350rpx;"
					class="w-100 border-1 shadow-lg">
			</view>
			</image>
			<view><button @click="uploadImage">上传图片</button></view>
		</view>
		<view class="form-item">
			<view class="form-label">联系电话：</view>
			<input class="h-100" v-model="formData.phone_number" placeholder="联系电话" />
		</view>
		<view class="form-item">
			<view class="form-label">营业时间：</view>
			<input class="h-100" v-model="formData.business_hours" placeholder="营业时间" />
		</view>
		<view class="form-item">
			<view class="form-label">特别优惠：</view>
			<input class="h-100" v-model="formData.special_offers" placeholder="特别优惠" />
		</view>
		<view class="form-item">
			<view class="form-label">详细信息：</view>
			<input class="h-100" v-model="formData.description" placeholder="详细信息" />
		</view>
		<view class="form-item">
			<view class="form-label">综合评分：</view>
			<slider v-model="formRating.overall_rating" :min="0" :max="5" show-value activeColor="#FFCC33"
				backgroundColor="#F76260" block-color="#8A6DE9" block-size="20"
				@change="handleSliderChange('overall_rating', $event)" />
		</view>
		<view class="form-item">
			<view class="form-label">口味：</view>
			<slider v-model="formRating.taste_rating" :min="0" :max="5" show-value activeColor="#FFCC33"
				backgroundColor="#F76260" block-color="#8A6DE9" block-size="20"
				@change="handleSliderChange('taste_rating', $event)" />
		</view>
		<view class=" form-item">
			<view class="form-label">服务：</view>
			<slider v-model="formRating.service_rating" :min="0" :max="5" show-value activeColor="#FFCC33"
				backgroundColor="#F76260" block-color="#8A6DE9" block-size="20"
				@change="handleSliderChange('service_rating', $event)" />
		</view>
		<view class="form-item">
			<view class="form-label">清洁度：</view>
			<slider v-model="formRating.cleanliness_rating" :min="0" :max="5" show-value activeColor="#FFCC33"
				backgroundColor="#F76260" block-color="#8A6DE9" block-size="20"
				@change="handleSliderChange('cleanliness_rating', $event)" />
		</view>
		<view class="form-item">
			<button @click="submitForm">提交</button>
		</view>
	</view>
</template>

<script>
	export default {
		onShow() {
			this.formData.longitude = this.$route.query.longitude
			this.formData.latitude = this.$route.query.latitude
		},
		data() {
			return {
				formData: {
					longitude: '',
					latitude: '',
					name: '',
					description: '',
					address: '',
					phone_number: '',
					business_hours: '',
					special_offers: '',
					description: '',
					imageUrls: '',
					environment: '',
					consumption: '',
					services: '',
				},
				formRating: {
					user_id: getApp().globalData.C_UserId,
					overall_rating: 0,
					taste_rating: 0,
					service_rating: 0,
					cleanliness_rating: 0,
					business_id: 0,
				},
			};
		},
		methods: {
			handleSliderChange(key, event) {
				console.log('Slider value changed:', event.detail.value);
				this.formRating[key] = event.detail.value;
			},
			submitForm() {
				if (this.validateForm()) {
					// 发送请求将数据提交到后台数据库
					uni.request({
						url: 'http://127.0.0.1:8002/api/business/create/business',
						method: 'POST',
						data: this.formData,
						success: (res) => {
							this.formRating.business_id = res.data.id
							console.log('新增成功', res.data);
							uni.request({
								url: 'http://127.0.0.1:8002/api/user/create/userBusinessRating',
								method: 'POST',
								data: this.formRating,
								success: (res) => {
									console.log('新增成功', res.data);
									uni.showToast({
										title: "创建成功"
									})
									uni.navigateBack({
										delta: 2
									})
								},
								fail: (err) => {
									console.error('新增失败', err);
								},
							})
						},
						fail: (err) => {
							console.error('新增失败', err);
						},
					});
				}
				console.log(this.formData)
				console.log(this.formRating)
			},
			uploadImage() {
				uni.chooseImage({
					count: 1, // 最多选择一张图片
					sizeType: ['compressed'], // 压缩图片
					sourceType: ['album', 'camera'], // 选择图片的来源，相册或相机
					success: (res) => {
						this.formData.imageUrls = res.tempFilePaths[0];
						uni.uploadFile({
							url: 'http://127.0.0.1:8002/upload/businessImage',
							filePath: res.tempFilePaths[0],
							name: 'file',
							success: (uploadFileRes) => {
								console.log('上传成功', uploadFileRes.data);
								this.formData.imageUrls = uploadFileRes.data
								console.log('上传成功2', this.formData.imageUrls);
							},
							fail: (err) => {
								console.error('上传失败', err);
							}
						});
					},
					fail: (err) => {
						console.error('选择图片失败', err);
					},
				});
			},

			validateForm() {
				// 检查每个字段是否为空
				const fields = [{
						key: 'name',
						label: '名称'
					},

					{
						key: 'address',
						label: '地址'
					},
					{
						key: 'phone_number',
						label: '联系电话'
					},
					{
						key: 'business_hours',
						label: '营业时间'
					},
					{
						key: 'special_offers',
						label: '特别优惠'
					},
					{
						key: 'description',
						label: "详细信息"
					},
					{
						key: 'imageUrls',
						label: "图片"
					}
				];

				for (const field of fields) {
					if (!this.formData[field.key].trim()) {
						uni.showToast({
							title: `${field.label}不能为空`,
							icon: 'none'
						});
						return false;
					}
				}
				return true; // 所有字段都通过验证
			},

			// clearForm(e) {
			// 	// 清空表单数据
			// 	if (e == "formData")
			// 		this.formData = {
			// 			name: '',
			// 			description: '',
			// 			address: '',
			// 			phone_number: '',
			// 			business_hours: '',
			// 			special_offers: '',
			// 			description: '',
			// 			imageUrls: ','
			// 		};
			// 	else
			// 		this.formRating = {
			// 			user_id: getApp().globalData.C_UserId,
			// 			overall_rating: 0,
			// 			taste_rating: 0,
			// 			service_rating: 0,
			// 			cleanliness_rating: 0,
			// 		};
			// },
		},
	};
</script>

<style scoped>
	.container {
		padding: 40rpx;
	}

	.form-item {
		margin-bottom: 40rpx;
	}

	.form-label {
		font-weight: bold;
	}

	input,
	textarea,
	button {
		width: 100%;
		padding: 10rpx;
		box-sizing: border-box;
		border: 1px solid #ccc;
		border-radius: 5rpx;
	}

	textarea {
		height: 80rpx;
	}

	button {
		background-color: #007bff;
		color: #fff;
		border: none;
		border-radius: 5rpx;
		font-size: 16rpx;
		cursor: pointer;
	}

	button:hover {
		background-color: #0056b3;
	}
</style>