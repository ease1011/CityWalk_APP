<template>
	<view>
		<uni-list-item title="头像" @click.native="changeUserAvatar">
			<image slot="right" :src="userInfo.avatar" mode="aspectFill" style="width: 150rpx;height: 150rpx;"
				class="rounded-circle"></image>
		</uni-list-item>
		<uni-list-item title="背景" class="py-1" @click.native="changeUserBackground">
			<image slot="right" :src="userInfo.background_image" mode="aspectFill" style="width: 80%;" class="rounded">
			</image>
		</uni-list-item>

		<uni-list-item title="昵称" class="flex" @click.native="changeUserNickname">
			<input class="uni-input text-right" v-model="userInfo.user_nick_name" />
			<text slot="right">{{ userInfo.user_nick_name }}</text>
		</uni-list-item>
		<uni-list-item title="签名" class="flex" @click.native="changeUserBio">
			<input class="uni-input text-right" v-model="userInfo.bio" />
			<text slot="right" class="text-ellipsis">{{ userInfo.bio }}</text>
		</uni-list-item>
		<!-- <uni-list-item title="性别" @click.native="changeUserSex">
			<text slot="right">{{ userInfo.gender }}</text>
		</uni-list-item> -->
		<picker mode="date" :value="userInfo.birthday" @change="onDateChange">
			<uni-list-item title="生日">
				<text slot="right">{{ userInfo.birthday | formatDate }}</text>
			</uni-list-item>
		</picker>

		<uni-list-item title="地区" @click.native="showCityPicker">
			<text slot="right">{{ userInfo.city }}</text>
		</uni-list-item>
		<view class="py-2 px-3">
			<button class="btn btn-warning w-50 mt-2" @click="backToMine"> 返回</button>
			<button class="btn btn-primary w-50 mt-2" @click="updateUserinfo"> 完成</button>
		</view>
		<mpvue-city-picker :themeColor="themeColor" ref="mpvueCityPicker" :pickerValueDefault="cityPickerValueDefault"
			@onConfirm="onConfirm"></mpvue-city-picker>
	</view>
</template>

<script>
	// const sexArray = ['保密', '男', '女'];
	import uniListItem from "@/components/uni-ui/uni-list/components/uni-list-item/uni-list-item.vue";
	import uniList from "@/components/uni-ui/uni-list/components/uni-list/uni-list.vue";
	import mpvueCityPicker from '@/components/uni-ui/mpvue-citypicker/mpvueCityPicker.vue';

	export default {
		components: {
			uniListItem,
			uniList,
			mpvueCityPicker
		},
		data() {
			return {
				themeColor: '#007AFF',
				cityPickerValueDefault: [0, 0, 1],
				userInfo: {
					username: '',
					avatar: "/static/topicpic.jpg",
					background_image: "/static/castle.jpg",
					user_nick_name: 'CityWalkerrr',
					bio: '大家好，我是海事烹鱼宴，热爱城市游！',
					gender: '保密',
					birthday: '2002-10-11',
					city: '上海'
				}
			};
		},
		// 监听返回
		onBackPress() {
			if (this.$refs.mpvueCityPicker.showPicker) {
				this.$refs.mpvueCityPicker.pickerCancel();
				return true;
			}
		},
		mounted() {
			this.getUserInfo();
		},
		methods: {
			filters: {
				formatTime(value) {
					return $T.gettime(value)
				}
			},
			getUserInfo() {
				this.userInfo.userId = getApp().globalData.C_UserId;
				uni.request({
					url: 'http://127.0.0.1:8002/api/user/' + this.userInfo.userId,
					method: 'GET',
					success: (res) => {
						console.log(res.data);
						this.userInfo = res.data; // 更新userInfo
					},
					fail: (error) => {
						console.log("获取用户信息失败", error);
					}
				});
			},
			updateUserinfo() {
				console.log("按道理的username" + this.userInfo.username);
				console.log("更新前用户信息：", this.userInfo);
				let updatedData = {};
				if (this.userInfo.user_nick_name !== null && this.userInfo.user_nick_name !== undefined && this.userInfo
					.user_nick_name !== '') {
					updatedData.user_nick_name = this.userInfo.user_nick_name;
				}
				if (this.userInfo.bio !== null && this.userInfo.bio !== undefined && this.userInfo.bio !== '') {
					updatedData.bio = this.userInfo.bio;
				}
				if (this.userInfo.background_image !== null && this.userInfo.background_image !== undefined && this
					.userInfo.background_image !== '') {
					updatedData.background_image = this.userInfo.background_image;
				}
				if (this.userInfo.avatar !== null && this.userInfo.avatar !== undefined && this
					.userInfo.avatar !== '') {
					updatedData.avatar = this.userInfo.avatar;
				}
				// if (this.userInfo.gender !== null && this.userInfo.gender !== undefined && this.userInfo.gender !== '') {
				// 	updatedData.gender = this.userInfo.gender;
				// }
				if (this.userInfo.city !== null && this.userInfo.city !== undefined && this.userInfo.city !== '') {
					updatedData.city = this.userInfo.city;
				}
				if (this.userInfo.birthday !== null && this.userInfo.birthday !== undefined && this.userInfo.birthday !==
					'') {
					updatedData.birthday = this.userInfo.birthday;
				}
				uni.request({
					url: 'http://127.0.0.1:8002/api/user/userinfo/' + this.userInfo.username,
					method: 'PUT',
					header: {
						'Content-Type': 'application/json'
					},
					data: updatedData,
					success: (res) => {
						console.log("成功返回", res);
						this.userInfo = res.data; // 更新userInfo
					},
					fail: (error) => {
						console.log("更新用户信息失败", error);
					},
					complete: () => {
						console.log("更新后用户信息：", this.userInfo);
						uni.switchTab({
							url: '/pages/mine/mine'
						});
					}
				});
			},

			backToMine() {
				uni.switchTab({
					url: "/pages/mine/mine"
				})
			},
			// 三级联动提交事件
			onConfirm(e) {
				this.userInfo.city = e.label;
				console.log(this.userInfo.city);
			},
			showCityPicker() {
				this.$refs.mpvueCityPicker.show();
			},

			// 修改头像
			changeUserAvatar() {
				console.log("修改头像");
				uni.chooseImage({
					count: 1,
					sizeType: ['original'],
					sourceType: ['album', 'camera'],
					success: (res) => {
						this.userInfo.avatar = res.tempFilePaths[0];
						uni.uploadFile({
							url: 'http://127.0.0.1:8002/upload/avatar',
							filePath: res.tempFilePaths[0],
							name: 'file',
							success: (uploadFileRes) => {
								console.log('上传成功', uploadFileRes.data);
								this.userInfo.avatar = uploadFileRes.data
							},
							fail: (err) => {
								console.error('上传失败', err);
							}
						});
					}
				});
			},
			changeUserBackground() {
				console.log("修改背景");
				uni.chooseImage({
					count: 1,
					sizeType: ['original'],
					sourceType: ['album', 'camera'],
					success: (res) => {
						this.userInfo.background_image = res.tempFilePaths[0];
						uni.uploadFile({
							url: 'http://127.0.0.1:8002/upload/backgroundImage',
							filePath: res.tempFilePaths[0],
							name: 'file',
							success: (uploadFileRes) => {
								console.log('上传成功', uploadFileRes.data);
								this.userInfo.background_image = uploadFileRes.data
							},
							fail: (err) => {
								console.error('上传失败', err);
							}
						});
					}
				});
			},

			changeUserNickname() {
				uni.showModal({
					title: '请输入新昵称',
					content: this.userInfo.user_nick_name,
					editable: true,
					placeholderText: '新昵称',
					confirmText: '确认',
					cancelText: '取消',
					success: (res) => {
						console.log(res);
						if (res.confirm) {
							if (res.content.trim() === '') {
								uni.showToast({
									title: '昵称不能为空',
									icon: 'none'
								});
								return;
							}
							this.userInfo.user_nick_name = res.content;
							console.log('输入的内容：', res.content);
						}
					}
				});
				console.log("修改昵称");
			},
			changeUserBio() {
				uni.showModal({
					title: '请输入新签名',
					content: this.userInfo.bio,
					editable: true,
					placeholderText: '新签名',
					confirmText: '确认',
					cancelText: '取消',
					success: (res) => {
						console.log(res);
						if (res.confirm) {
							this.userInfo.bio = res.content;
							console.log('输入的内容：', res.content);
						}
					}
				});
				console.log("修改签名");
			},
			changeUserSex() {
				uni.showActionSheet({
					itemList: sexArray,
					success: (res) => {
						this.userInfo.gender = sexArray[res.tapIndex];
						console.log(res.tapIndex);
					},
				});
			},
			// 修改生日
			onDateChange(e) {
				this.userInfo.birthday = e.detail.value;
				console.log(e.detail.value);
			}
		}
	}
</script>

<style></style>