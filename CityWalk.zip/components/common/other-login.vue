<template>
	<view>
		<view class="flex align-center justify-center">
			<view style="height: 1rpx;background-color: #dddddd;width: 100rpx;"></view>
			<view class="mx-2 text-muted">社交账号登录</view>
			<view style="height: 1rpx;background-color: #dddddd;width: 100rpx;"></view>
		</view>
		<view class="flex justify-content-between mt-3 ">
			<text></text>
			<text class="iconfont icon-QQ" style="font-size: 26px; color: royalblue"></text>
			<text class="iconfont icon-weixin" style="font-size: 26px; color: green"></text>
			<text></text>
		</view>
		<!-- <view v-for="item in providerList" :key="item.id"
			:class="item.icon + ' ' + item.bgColor + ' iconfont font-lg text-white flex align-center justify-center rounded-circle'"
			style="width: 100rpx; height: 100rpx;">
			{{ item.name }}
		</view> -->
	</view>
</template>

<script>
	export default {
		data() {
			return {
				providerList: []
			}
		},
		mounted() {
			uni.getProvider({
				service: 'oauth',
				success: (result) => {
					this.providerList = result.provider.map((value) => {
						let providerName = '';
						let icon = '';
						let bgColor = '';
						switch (value) {
							case 'weixin':
								providerName = '微信登录';
								icon = 'icon-weixin';
								bgColor = 'bg-success';
								break;
							case 'qq':
								providerName = 'QQ登录';
								icon = 'icon-QQ';
								bgColor = 'bg-primary';
								break;
							case 'apple':
								providerName = '苹果登录';
								break;
							case 'univerify':
								providerName = '一键登录';
								break;
						}
						return {
							name: providerName,
							icon: icon,
							bgColor: bgColor,
							id: value
						};
					});
					console.log(this.providerList); // 在这里进行 console.log
				},
				fail: (error) => {
					console.log('获取登录通道失败', error);
				}
			});
		}
	}
</script>

<style>
</style>