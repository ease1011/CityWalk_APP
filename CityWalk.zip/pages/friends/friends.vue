<template>
	<view class="profile">
		<!-- 主要内容区域 -->
		<view class="container h-100">
			<!-- 选项卡 -->
			<view class="profile-tabs">
				<view class="profile-tab" v-for="(tab, index) in tabs" :key="index" @click="changeTab(index)"
					:class="{ 'active': activeTabIndex === index }">
					{{ tab.title }}
					<text class="font-sm text-secondary p-2"> {{ tab.num }}</text>
				</view>
			</view>
			<!-- 内容 -->
			<view class="profile-users mr-3">
				<view class="profile-user" v-for="user in TabUsers" :key="user.id" @click="goToUserSpace(user.id)">
					<view class="profile-user btn">
						<img :src="user.avatar" class="profile-avatar" alt="User Avatar">
						<view class="user-info">
							<view class="profile-username">{{ user.display_name }}</view>
						</view>
					</view>
					<view class="border-bottom"></view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				tabs: [{
						title: "好友",
						users: [],
						num: 0,
					},
					{
						title: "关注",
						users: [],
						num: 0,
					},
					{
						title: "粉丝",
						users: [],
						num: 0,
					},
				],
				activeTabIndex: 0,
			};
		},
		computed: {
			TabUsers() {
				return this.tabs[this.activeTabIndex].users;
			},
		},
		methods: {
			changeTab(index) {
				this.activeTabIndex = index;
				if (this.tabs[index].users.length === 0) {
					this.fetchDataForTab(index);
				}
			},
			updateTabUsers(tabIndex, users) {
				this.$set(this.tabs, tabIndex, {
					...this.tabs[tabIndex],
					users: users.map((user) => {
						return {
							id: user.id,
							display_name: user.user_nick_name,
							avatar: user.avatar,
						};
					}),
					num: users.length,
				});
			},
			fetchDataForTab(tabIndex) {
				let url = "";
				if (tabIndex === 0) {
					url =
						"http://127.0.0.1:8002/api/user-relationship/user/" +
						getApp().globalData.C_UserId +
						"/mutual-followers-details";
				} else if (tabIndex === 1) {
					url =
						"http://127.0.0.1:8002/api/user-relationship/user/" +
						getApp().globalData.C_UserId +
						"/following-details";
				} else if (tabIndex === 2) {
					url =
						"http://127.0.0.1:8002/api/user-relationship/user/" +
						getApp().globalData.C_UserId +
						"/followers-details";
				}

				fetch(url)
					.then((response) => response.json())
					.then((data) => {
						this.updateTabUsers(tabIndex, data);
					})
					.catch((error) => {
						console.error("匹配错误:", error);
					});
			},
			goToUserSpace(userId) {
				uni.navigateTo({
					url: "/pages/user-space/user-space?id=" + userId
				});
			},

		},
		onShow() {
			this.fetchDataForTab(this.activeTabIndex);
		},
		created() {
			const userId = this.$route.query.id;
			if (userId) {
				// 根据用户ID请求数据
				let url = "http://127.0.0.1:8002/api/user/" + userId + "/details";

				fetch(url)
					.then((response) => response.json())
					.then((data) => {
						this.User = {
							username: data.user_nick_name,
							avatar: data.avatar,
							backgroundImage: data.background_image,
							bio: data.bio,
							city: data.city,
							followersCount: data.followersCount,
							followingCount: data.followingCount,
							posts: [], // 如果有用户的动态数据，也可以在这里获取并赋值
						};
					})
					.catch((error) => {
						console.error("Error fetching user data:", error);
					});
			}
		},

	};
</script>

<style lang="scss" scoped>
	.profile {
		display: flex;

		.container {
			flex: 1;
			padding: 10px;
		}

		.profile-tabs {
			display: flex;
			justify-content: space-around;
			padding: 10px 0;

			.profile-tab {
				font-size: 18px;
				padding: 10px;
				cursor: pointer;
				color: black;
				border-bottom: 2px solid transparent;
				transition: border-color 0.3s;

				&.active {
					font-size: 20px;
					font-weight: bold;
					color: royalblue;
					border-bottom-color: royalblue;
				}
			}
		}

		.profile-users {
			margin-top: 14px;

			.profile-user {
				margin-bottom: 20px;

				.profile-user {
					display: flex;
					align-items: center;
					margin-bottom: 4px;
					margin-top: -6px;

					.profile-avatar {
						width: 50px;
						height: 50px;
						border-radius: 50%;
						margin-right: 10px;
					}

					.user-info {
						.profile-username {
							margin-left: 10px;
							font-size: 22px;
							font-weight: bold;
							color: #333;
							letter-spacing: 2px;
						}
					}
				}

				.border-bottom {
					border-bottom: 1px solid #eee;
				}
			}
		}
	}
</style>