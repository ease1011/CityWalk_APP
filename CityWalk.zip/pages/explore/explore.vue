<template>
	<view class="pb-2">
		<!-- 话题 -->
		<scroll-view class="mt-3 h-100 py-3">
			<view class="navbar-box">
				<button class="btn-favorite" @click="showFavoriteTopics">我的收藏</button>
			</view>
			<swiper class="px-2 pb-2 mt-3" :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000">
				<swiper-item class="align-center justify-center">
					<image mode="aspectFill" src="/static/castle.jpg" class="rounded-4 w-100" style="height: 100%;">
					</image>
				</swiper-item>
			</swiper>
			<divider></divider>
			<!-- 最近更新 -->
			<view class="p-2 font-md">
				<view class="flex">最近更新</view>
			</view>
			<!-- 话题组件 -->
			<block v-for="(item,index) in topicList" :key="index">
				<topic-list :item="item" :index="index"></topic-list>
			</block>
		</scroll-view>

		<!-- 弹窗 -->
		<view class="modal" v-if="showModal">
			<view class="modal-content">
				<view class="modal-header">
					<text class="modal-title">我的收藏</text>
				</view>
				<block v-for="(item, index) in favoriteTopicList" :key="index">
					<view class="topic-item" @click="gotoTopicDetail(item.id)">
						<image :src="item.coverImage" class="topic-image"></image>
						<view class="topic-info">
							<view class="topic-name">{{ item.title }}</view>
							<view class="topic-description">{{ item.description }}</view>
						</view>
					</view>
				</block>
				<button class="btn btn-danger" @click="closeModal">关闭</button>
			</view>
		</view>
	</view>
</template>

<script>
	import uniNavBar from '@/components/uni-ui/uni-nav-bar/uni-nav-bar.vue';
	import commonList from "@/components/common/common-list.vue";
	import loadMore from "@/components/common/load-more.vue";
	import hotCate from "@/components/expore/hot-cate.vue";
	import topicList from "@/components/expore/topic-list.vue";

	export default {
		components: {
			uniNavBar,
			commonList,
			loadMore,
			hotCate,
			topicList
		},
		data() {
			return {
				user_id: getApp().globalData.C_UserId,
				tabIndex: 0,
				tabBars: [{
					name: "话题"
				}],
				// 关注列表
				loadMore: "上拉加载更多",
				topicList: [{
					id: 3,
					coverImage: "/static/pic1 (8).jpg",
					description: "CityWalk？",
					title: "外滩探索~",
					postCount: 0,
				}],
				showModal: false, // 控制弹窗显示与隐藏
				favoriteTopicList: [],
			}
		},
		onLoad() {

		},
		onShow() {
			this.getData();
		},
		methods: {
			getData() {
				uni.request({
					url: 'http://127.0.0.1:8002/api/topic/topics',
					success: (res) => {
						this.topicList = res.data
					}
				})
			},
			gotoTopicDetail(id) {
				// 点击跳转到详情页，并传递话题id
				uni.navigateTo({
					url: '/pages/topic-detail/topic-detail?id=' + id,
				});
			},
			// 打开发布页
			openAddInput() {
				uni.navigateTo({
					url: '/pages/add-input/add-input'
				})
			},
			// 切换选项卡
			changeTab(index) {
				this.tabIndex = index
				console.log(this.tabIndex)
			},
			onChangeTab(e) {
				this.tabIndex = e.detail.current
			},
			// 顶踩
			doSupport(e) {
				console.log(this.list[e.index].support.type)
				let msg = this.list[e.index].support.type;
				console.log(msg)
				if (msg) {
					this.list[e.index].support.supportCount--
					uni.showToast({
						title: '取消点赞成功'
					});
				} else {
					this.list[e.index].support.supportCount++
					uni.showToast({
						title: '点赞成功'
					});
				}
				this.list[e.index].support.type = !this.list[e.index].support.type
			},
			doFavorite(e) {
				const index = e.index;
				const favorite = this.list[index].favorite;
				if (favorite.type) {
					favorite.favoriteCount--;
					uni.showToast({
						title: '取消收藏成功',
					});
				} else {
					favorite.favoriteCount++;
					uni.showToast({
						title: '收藏成功'
					});
				}
				favorite.type = !favorite.type;
				console.log("当前在" + index)
				console.log(this.list[index])
				console.log("收藏的数量" + this.list[index].favorite.favoriteCount)
			},
			// 上拉加载更多
			loadmoreEvent() {
				// 判断是否处于可加载状态
				if (this.loadMore !== '上拉加载更多') return
				// 修改当前列表加载状态
				this.loadMore = '加载中...'
				// 模拟数据请求
				setTimeout(() => {
					// 加载数据
					this.list = Array.from(this.list).concat(Array.from(this.list))
					// this.list = [...this.list, ...this.list]
					// 恢复加载状态
					this.loadMore = '上拉加载更多'
				}, 1000)
			},
			// 打开搜索
			openSearch() {
				uni.navigateTo({
					url: '/pages/search/search'
				})
			},
			// 显示我的收藏弹窗
			showFavoriteTopics() {
				this.showModal = true;
				uni.request({
					url: `http://127.0.0.1:8002/api/user-topic-favorite/${getApp().globalData.C_UserId}/favorite-topics-details`,
					method: 'GET',
					success: (res) => {
						console.log(res.data);
						this.favoriteTopicList = res.data
					},
					fail: (error) => {
						console.error('请求失败:', error);
					}
				});
			},
			// 关闭我的收藏弹窗
			closeModal() {
				this.showModal = false;
			}
		},
	}
</script>

<style>
	.navbar-box {
		display: flex;
		align-items: center;
		justify-content: flex-end;
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		padding: 10px;
		background-color: rgba(red, green, blue, 0);
		z-index: 999;
	}

	/* 样式化按钮 */
	.btn-favorite {
		background-color: #409eff;
		color: #fff;
		padding: 8px 16px;
		border-radius: 20px;
		margin-right: 10px;
		font-size: 14px;
		border: none;
		outline: none;
		cursor: pointer;
	}

	/* 弹窗样式 */
	.modal {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0.5);
		display: flex;
		justify-content: center;
		align-items: center;
		z-index: 1000;
	}

	.modal-content {
		background-color: #fff;
		border-radius: 10px;
		padding: 20px;
		width: 80%;
		max-height: 80%;
		overflow-y: auto;
	}

	.modal-header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 10px;
	}

	.modal-title {
		font-size: 18px;
		font-weight: bold;
	}

	.close-btn {
		background-color: #409eff;
		color: #fff;
		padding: 8px 16px;
		border-radius: 20px;
		border: none;
		outline: none;
		cursor: pointer;
	}

	.close-btn:hover {
		background-color: #66b1ff;
	}

	/* 话题样式 */
	.topic-item {
		display: flex;
		margin-bottom: 20px;
	}

	.topic-image {
		width: 80px;
		height: 80px;
		border-radius: 5px;
		margin-right: 10px;
	}

	.topic-info {
		flex: 1;
	}

	.topic-name {
		font-size: 16px;
		font-weight: bold;
		margin-bottom: 5px;
	}

	.topic-description {
		font-size: 14px;
		color: #666;
	}
</style>