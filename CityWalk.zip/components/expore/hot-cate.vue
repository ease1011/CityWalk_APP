<template>
	<view class="">
		<view class="flex align-center justify-between px-2">
			<text class="font-md">热门分类</text>
			<view class="flex align-center font text-secondary animated" hover-class="tada" @click="openMore">
				更多<text class="iconfont icon-arrow-right-bold "></text>
			</view>
		</view>
		<view class="flex align-center px-2 py-3 border-bottom">
			<view class="border rounded btn bg-light mx-2 px-2 animated " hover-class="tada"
				v-for="(item,index) in hotCate" :key="index" @click="openDetail(item)">
				{{item.name}}
			</view>
		</view>
	</view>
</template>


<script>
	export default {
		props: ['hotCate'],
		methods: {
			openMore() {
				uni.navigateTo({
					url: '/pages/topic-nav/topic-nav'
				})
				console.log('更多')
			},
			openDetail() {
				console.log('打开话题分类页');
			}
		}
	}
</script>

<style>
</style>