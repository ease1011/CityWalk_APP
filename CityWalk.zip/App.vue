<script>
	export default {
		onLaunch: function() {
			// var script = document.createElement('script');
			// script.src = "https://webapi.amap.com/maps?v=2.0&key=608b2fd05c7b7bcdad1e6e677592328e";
			// document.head.appendChild(script);

		},
		onShow: function() {},
		onHide: function() {},


		globalData: {
			C_Username: 'Alice',
			C_UserId: 1,
			C_UserNickName: '爱丽丝~',
			C_UserAvatar: '/static/topicpic.jpg',
		}
	}
</script>
<!-- <link href="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/5.3.1/css/bootstrap-grid.css" rel="stylesheet"> -->
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> -->
<!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script> -->
<style>
	/*每个页面公共css */
	/* 官方CSS库 */
	@import "./common/uni.css";
	/* 自定义图标库 */
	@import "./common/iconfont.css";
	/* 引入动画库 */
	@import "./common/animate.css";
	/* 引入推特css库 */
	@import "common/twitter.css";
	/* 引入index样式 */
	@import "common/index_setting.css";
	/* 引入free样式 */
	@import "common/free.css";
	/* 引入公用组件样式 */
	@import "common/common.css";
</style>