<template>
	<view>
		<!-- 搜索框 -->
		<view>
			<!-- 搜索发帖框 -->
			<view class="search-box">
				<view class="btn btn-primary" @click="gotoSearch">
					<text class="iconfont icon-sousuo">搜索</text>
				</view>
				<view class="btn btn-info" @click="gotoAddInput">
					<text class="iconfont icon-edit">发帖</text>
				</view>
			</view>
		</view>
		<!-- 顶部选项卡 -->
		<view class="container">
			<scroll-view scroll-x :scroll-into-view="scrollInto" scroll-with-animation class="border-0"
				style="height: 100rpx;">
				<view v-for="(item,index) in tabBars" :key="index" class="scroll-row-item px-3 py-2 font-md"
					:id="'tab'+index" :class="tabIndex===index?'text-main font-lg font-weight-bold':''"
					@click="changeTab(index)">
					{{item.name}}
				</view>
			</scroll-view>
			<swiper :duration="150" :current="tabIndex" @change="onChangeTab" :style="'height:'+scrollH+'px;'">
				<swiper-item v-for="(item,index) in newsList" :key="index">
					<scroll-view scroll-y="true" :style="'height:'+scrollH+'px;'" @scrolltolower="loadmore(index)">
						<template v-show="item.list.length > 0">
							<block v-for="(item2,index2) in item.list" :key="index2">
								<!-- 列表样式 -->
								<common-list :item="item2" :index="index2" @follow="follow" @doLike="doLike"
									@doFavorite="doFavorite"></common-list>
								<!-- 全局分割线 -->
								<divider></divider>
							</block>
							<!-- 上拉加载 -->
							<load-more :loadmore="item.loadmore"></load-more>
						</template>
						<!-- 无数据 -->
						<template v-show="item.list.length === 0">
							<no-thing></no-thing>
						</template>
					</scroll-view>
				</swiper-item>
			</swiper>
		</view>

	</view>
</template>

<script>
	import commonList from "@/components/common/common-list.vue";
	import loadMore from "@/components/common/load-more.vue";

	export default {
		components: {
			commonList,
			loadMore
		},
		data() {
			return {
				tabIndex: 0,
				scrollH: 600,
				scrollInto: 'tabIndex',
				tabBars: [{
						name: "关注",
					},
					{
						name: "最新",
					},
					{
						name: "推荐",
					}
				],
				newsList: [{}]
			}
		},
		onLoad() {},
		mounted() {
			this.getData()
		},
		onShow() {
			uni.getSystemInfo({
				success: res => {
					this.scrollH = res.windowHeight - uni.upx2px(100)
				}
			})
		},
		methods: {
			gotoSearch() {
				uni.navigateTo({
					url: '/pages/search/search'
				});
			},
			gotoAddInput() {
				uni.navigateTo({
					url: '/pages/add-input/add-input'
				});
			},
			getData() {
				this.newsList = this.tabBars.map((item, index) => {
					let obj = {
						loadmore: "上拉加载更多",
						list: []
					};
					if (index == 0) {
						uni.request({
							url: "http://127.0.0.1:8002/api/post/following-posts-with-stats/" + getApp()
								.globalData.C_UserId,
							method: 'GET',
							success: (res) => {
								for (let i = 0; i < res.data.length; i++) {
									let imageUrlArray = JSON.parse(res.data[i].post.image_url);
									let newData = {
										PostId: res.data[i].post.id,
										UserId: res.data[i].userDetailsProjection.id,
										user_nick_name: res.data[i].userDetailsProjection
											.user_nick_name,
										user_avatar: res.data[i].userDetailsProjection.avatar,
										create_time: res.data[i].post.create_time,
										isFollow: true,
										description: res.data[i].post.description,
										image_url: imageUrlArray[0],
										like: {
											type: false,
											likeCount: res.data[i].postStats.likeCount,
										},
										favorite: {
											type: false,
											favoriteCount: res.data[i].postStats.favoriteCount,
										},
										commentCount: 0,
										shareCount: res.data[i].postStats.shareCount,
									};
									uni.request({ //获取评论数
										url: 'http://127.0.0.1:8002/api/comment/post/' + res
											.data[i].post.id,
										success: (res) => {
											newData.commentCount = res.data.length
										}
									}); //获取点赞状态
									uni.request({
										url: 'http://127.0.0.1:8002/api/user-likes/' +
											getApp().globalData.C_UserId +
											'/post/' + res.data[i].post.id +
											'/likes',
										method: 'GET',
										success: (res) => {
											newData.like.type = res.data
										}
									}); //获取收藏状态
									uni.request({
										url: 'http://127.0.0.1:8002/api/user-favorite/' +
											getApp().globalData.C_UserId +
											'/post/' + res.data[i].post.id +
											'/favorite',
										method: 'GET',
										success: (res) => {
											newData.favorite.type = res.data
										}
									});
									obj.list.push(newData);
								}
							},
							fail: (err) => {
								console.log(err)
							}
						})
					}
					if (index == 1) {
						uni.request({
							url: "http://127.0.0.1:8002/api/post/latest-posts-with-stats",
							method: 'GET',
							success: (res) => {
								for (let i = 0; i < res.data.length; i++) {
									let imageUrlArray = JSON.parse(res.data[i].post.image_url);
									let newData = {
										PostId: res.data[i].post.id,
										UserId: res.data[i].userDetailsProjection.id,
										user_nick_name: res.data[i].userDetailsProjection
											.user_nick_name,
										user_avatar: res.data[i].userDetailsProjection.avatar,
										create_time: res.data[i].post.create_time,
										isFollow: true,
										description: res.data[i].post.description,
										image_url: imageUrlArray[0],
										like: {
											type: false,
											likeCount: res.data[i].postStats.likeCount,
										},
										favorite: {
											type: false,
											favoriteCount: res.data[i].postStats.favoriteCount,
										},
										commentCount: 0,
										shareCount: res.data[i].postStats.shareCount,
									};
									uni.request({ //获取评论数
										url: 'http://127.0.0.1:8002/api/comment/post/' + res
											.data[i].post.id,
										success: (res) => {
											newData.commentCount = res.data.length
										}
									}); //获取点赞状态
									uni.request({
										url: 'http://127.0.0.1:8002/api/user-likes/' +
											getApp().globalData.C_UserId +
											'/post/' + res.data[i].post.id +
											'/likes',
										method: 'GET',
										success: (res) => {
											newData.like.type = res.data
										}
									}); //获取收藏状态
									uni.request({
										url: 'http://127.0.0.1:8002/api/user-favorite/' +
											getApp().globalData.C_UserId +
											'/post/' + res.data[i].post.id +
											'/favorite',
										method: 'GET',
										success: (res) => {
											newData.favorite.type = res.data
										}
									});
									obj.list.push(newData);
								}
							},
							fail: (err) => {
								console.log(err)
							}
						})
					}
					if (index == 2) { //根据用户点赞来推荐
						uni.request({
							url: "http://127.0.0.1:8002/api/post/recommended-posts/" + getApp()
								.globalData.C_UserId,
							method: 'GET',
							success: (res) => {
								if (res.data.length > 0) {
									for (let i = 0; i < res.data.length; i++) {
										let imageUrlArray = JSON.parse(res.data[i].post.image_url);
										let newData = {
											PostId: res.data[i].post.id,
											UserId: res.data[i].userDetailsProjection.id,
											user_nick_name: res.data[i].userDetailsProjection
												.user_nick_name,
											user_avatar: res.data[i].userDetailsProjection.avatar,
											create_time: res.data[i].post.create_time,
											isFollow: true,
											description: res.data[i].post.description,
											image_url: imageUrlArray[0],
											like: {
												type: false,
												likeCount: res.data[i].postStats.likeCount,
											},
											favorite: {
												type: false,
												favoriteCount: res.data[i].postStats.favoriteCount,
											},
											commentCount: 0,
											shareCount: res.data[i].postStats.shareCount,
										};
										uni.request({ //获取评论数
											url: 'http://127.0.0.1:8002/api/comment/post/' +
												res
												.data[i].post.id,
											success: (res) => {
												newData.commentCount = res.data.length
											}
										}); //获取点赞状态
										uni.request({
											url: 'http://127.0.0.1:8002/api/user-likes/' +
												getApp().globalData.C_UserId +
												'/post/' + res.data[i].post.id +
												'/likes',
											method: 'GET',
											success: (res) => {
												newData.like.type = res.data
											}
										}); //获取收藏状态
										uni.request({
											url: 'http://127.0.0.1:8002/api/user-favorite/' +
												getApp().globalData.C_UserId +
												'/post/' + res.data[i].post.id +
												'/favorite',
											method: 'GET',
											success: (res) => {
												newData.favorite.type = res.data
											}
										});
										obj.list.push(newData);
									}
								} else {
									uni.request({
										url: "http://127.0.0.1:8002/api/post/all-posts-with-stats",
										method: 'GET',
										success: (res) => {
											for (let i = 0; i < res.data.length; i++) {
												let imageUrlArray = JSON.parse(res.data[i]
													.post.image_url);
												let newData = {
													PostId: res.data[i].post.id,
													UserId: res.data[i]
														.userDetailsProjection.id,
													user_nick_name: res.data[i]
														.userDetailsProjection
														.user_nick_name,
													user_avatar: res.data[i]
														.userDetailsProjection.avatar,
													create_time: res.data[i].post
														.create_time,
													isFollow: true,
													description: res.data[i].post
														.description,
													image_url: imageUrlArray[0],
													like: {
														type: false,
														likeCount: res.data[i]
															.postStats.likeCount,
													},
													favorite: {
														type: false,
														favoriteCount: res.data[i]
															.postStats.favoriteCount,
													},
													commentCount: 0,
													shareCount: res.data[i].postStats
														.shareCount,
												};
												uni.request({ //获取评论数
													url: 'http://127.0.0.1:8002/api/comment/post/' +
														res
														.data[i].post.id,
													success: (res) => {
														newData.commentCount =
															res.data.length
													}
												}); //获取点赞状态
												uni.request({
													url: 'http://127.0.0.1:8002/api/user-likes/' +
														getApp().globalData
														.C_UserId +
														'/post/' + res.data[i].post
														.id +
														'/likes',
													method: 'GET',
													success: (res) => {
														newData.like.type = res
															.data
													}
												}); //获取收藏状态
												uni.request({
													url: 'http://127.0.0.1:8002/api/user-favorite/' +
														getApp().globalData
														.C_UserId +
														'/post/' + res.data[i].post
														.id +
														'/favorite',
													method: 'GET',
													success: (res) => {
														newData.favorite.type =
															res.data
													}
												});
												obj.list.push(newData);
											}
										},
										fail: (err) => {
											console.log(err)
										}
									})
								}
							},
							fail: (err) => {
								console.log(err)
							}
						})
					}
					return obj;
				});
			},
			onChangeTab(e) {
				this.changeTab(e.detail.current)
			},
			changeTab(index) {
				if (this.tabIndex === index) {
					return
				}
				this.tabIndex = index
				this.scrollInto = 'tab' + index
			},
			follow(e) {
				this.newsList[this.tabIndex].list[e].isFollow = true;
				uni.showToast({
					title: '关注成功'
				});
			},
			doLike(e) {
				const index = e.index;
				const type = !this.newsList[this.tabIndex].list[index].like.type;
				const psid = this.newsList[this.tabIndex].list[index].PostId
				const urid = getApp().globalData.C_UserId
				if (type) {
					this.newsList[this.tabIndex].list[index].like.likeCount++;
					this.newsList[this.tabIndex].list[index].like.type = true;
					uni.showToast({
						title: '点赞成功'
					});
				} else {
					if (this.newsList[this.tabIndex].list[index].like.likeCount > 0) {
						this.newsList[this.tabIndex].list[index].like.likeCount--;
					}
					this.newsList[this.tabIndex].list[index].like.type = false;
					uni.showToast({
						title: '取消点赞成功'
					});
				}
				uni.request({
					url: `http://127.0.0.1:8002/api/user-likes/${urid}/post/${psid}/toggle-like`,
					method: 'POST',
				})
			},
			doFavorite(e) {
				const index = e.index;
				const psid = this.newsList[this.tabIndex].list[index].PostId
				const urid = getApp().globalData.C_UserId
				const type = !this.newsList[this.tabIndex].list[index].favorite.type;
				if (type) {
					this.newsList[this.tabIndex].list[index].favorite.favoriteCount++;
					this.newsList[this.tabIndex].list[index].favorite.type = true;
					uni.showToast({
						title: '收藏成功'
					});
				} else {
					if (this.newsList[this.tabIndex].list[index].favorite.favoriteCount > 0) {
						this.newsList[this.tabIndex].list[index].favorite.favoriteCount--;
					}
					this.newsList[this.tabIndex].list[index].favorite.type = false;
					uni.showToast({
						title: '取消收藏成功'
					});
				}
				uni.request({
					url: `http://127.0.0.1:8002/api/user-favorite/${urid}/post/${psid}/toggle-favorite`,
					method: 'POST',
				})
			},
			loadmore(index) {
				let item = this.newsList[index]
				if (item.loadmore !== '上拉加载更多') return
				item.loadmore = '加载中...'
				setTimeout(() => {
					item.list = [...item.list, ...item.list]
					item.loadmore = '上拉加载更多'
				}, 2000)
			},
		}
	}
</script>

<style scoped>
	.search-box {
		display: flex;
		align-items: center;
		justify-content: flex-end;
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		padding: 10px;
		background-color: rgba(red, green, blue, 0);
		z-index: 999;
	}

	.btn {
		margin-right: 10px;
	}

	.container {
		margin-top: 100rpx;
	}
</style>