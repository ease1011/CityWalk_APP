<template>
	<view class="flex align-center p-2" @click="open">
		<image :src="item.coverImage" class="rounded mr-2" style="height: 150rpx; width: 150rpx;"></image>
		<view class="flex flex-column flex-1">
			<text class="font-md text-dark">{{item.title}}</text>
			<text class="font text-secondary">{{item.description}}</text>
			<view class="flex align-center font text-secondary">
				<text class="mr-2">动态：{{item.postCount}}</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props: {
			item: Object,
			index: Number
		},
		methods: {
			open() {
				// 点击跳转到详情页，并传递话题id
				uni.navigateTo({
					url: '/pages/topic-detail/topic-detail?id=' + this.item.id,
				});
			}
		}
	}
</script>

<style>
</style>