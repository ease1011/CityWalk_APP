<template>
	<view class="container">
		<view class="form-item">
			<view class="form-label">名称：</view>
			<input class="h-100" v-model="formData.title" placeholder="请输入名称" />
		</view>
		<view class="form-item">
			<view class="form-label">图片：</view>
			<view v-if="formData.coverImage">
				<image :src="formData.coverImage" mode="aspectFill" style="height: 350rpx;"
					class="w-100 border-1 shadow-lg">
			</view>
			</image>
			<view><button @click="uploadImage">上传图片</button></view>
		</view>

		<view class="form-item">
			<view class="form-label">详细信息：</view>
			<input class="h-100" v-model="formData.description" placeholder="详细信息" />
		</view>

		<view class="form-item">
			<button @click="submitForm">提交</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				formData: {
					title: '',
					description: '',
					coverImage: '',
				},

			};
		},
		methods: {

			submitForm() {
				if (this.validateForm()) {
					// 发送请求将数据提交到后台数据库
					uni.request({
						url: 'http://127.0.0.1:8002/api/topic/create/topics',
						method: 'POST',
						data: this.formData,
						success: (res) => {
							console.log('新增成功', res.data);
							uni.showToast({
								title: "创建成功"
							})
							uni.navigateBack({
								delta: 1
							})
						},
						fail: (err) => {
							console.error('新增失败', err);
						},
					});
				}

			},
			uploadImage() {
				uni.chooseImage({
					count: 1, // 最多选择一张图片
					sizeType: ['compressed'], // 压缩图片
					sourceType: ['album', 'camera'], // 选择图片的来源，相册或相机
					success: (res) => {
						this.formData.coverImage = res.tempFilePaths[0];
						uni.uploadFile({
							url: 'http://127.0.0.1:8002/upload/topicImage',
							filePath: res.tempFilePaths[0],
							name: 'file',
							success: (uploadFileRes) => {
								console.log('上传成功', uploadFileRes.data);
								this.formData.coverImage = uploadFileRes.data
							},
							fail: (err) => {
								console.error('上传失败', err);
							}
						});
					},
					fail: (err) => {
						console.error('选择图片失败', err);
					},
				});
			},

			validateForm() {
				// 检查每个字段是否为空
				const fields = [{
						key: 'title',
						label: '名称'
					},
					{
						key: 'description',
						label: "详细信息"
					},
					{
						key: 'coverImage',
						label: "图片"
					}
				];

				for (const field of fields) {
					if (!this.formData[field.key].trim()) {
						uni.showToast({
							title: `${field.label}不能为空`,
							icon: 'none'
						});
						return false;
					}
				}
				return true; // 所有字段都通过验证
			},
		},
	};
</script>

<style scoped>
	.container {
		padding: 40rpx;
	}

	.form-item {

		margin-bottom: 40rpx;
	}

	.form-label {
		font-weight: bold;
	}

	input,
	textarea,
	button {
		width: 100%;
		padding: 10rpx;
		box-sizing: border-box;
		border: 1px solid #ccc;
		border-radius: 5rpx;
	}

	textarea {
		height: 80rpx;
	}

	button {
		background-color: #007bff;
		color: #fff;
		border: none;
		border-radius: 5rpx;
		font-size: 16rpx;
		cursor: pointer;
	}

	button:hover {
		background-color: #0056b3;
	}
</style>