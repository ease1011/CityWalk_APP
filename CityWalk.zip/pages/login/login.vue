<template>
	<view class="login-page flex">
		<view class="container">
			<view class="flex align-center">
				<image src="../../static/logo.png" mode="aspectFill" class="logo"></image>
				<h2 class="justify-center pl-5" v-if="!loginCard">==></h2>
				<h3 class="justify-center pl-2 m-1" @click="showLoginCard" :class="loginCard ? 'pl-5' : ''">登录CityWalk
				</h3>
			</view>

			<transition name="fade">
				<view v-if="loginCard" class="login-card">
					<template v-if="!status">
						<view class="mb-3">
							<label for="username" class="form-label my-3">CityWalkerID</label>
							<input type="text" v-model="username" class="border-bottom" placeholder="账号/用户名" />
						</view>
						<view class="mb-4">
							<label for="password" class="form-label my-3">密码</label>
							<input type="password" v-model="password" class="border-bottom" placeholder="请输入密码" />
						</view>
						<view class="flex justify-between">
							<view class="align-center justify-center animated" hover-class="text-main pulse "
								@click="changeStatus">
								点我注册！
							</view>
							<view class="align-center justify-center text-light-black font-small animated"
								hover-class="text-main pulse ">
								忘记密码？
							</view>
						</view>
						<button type="submit" class="btn btn-primary btn-block rounded-4" @click="submit">登录</button>
					</template>
					<template v-else>
						<view>
							<view class="iconfont icon-back h-100 font-weight-lighter font-sm " @click="changeStatus">
								返回账号登录
							</view>
							<view class="mb-3">
								<label for="username" class="form-label mb-3 mt-3">用户名</label>
								<view class="flex align-center mb-2">
									<!-- <text class="mr-2">+86</text> -->
									<view class="align-stretch flex-1">
										<input type="text" v-model="registerUsername" class="border-bottom"
											placeholder="请输入用户名" />
									</view>
								</view>
							</view>
							<view class="mb-3">
								<label for="nickname" class="form-label mb-3 mt-3">昵称</label>
								<view class="flex align-center mb-2">
									<!-- <text class="mr-2">+86</text> -->
									<view class="align-stretch flex-1">
										<input type="text" v-model="registerNickname" class="border-bottom"
											placeholder="请输入昵称" />
									</view>
								</view>
							</view>
							<view class="mb-3">
								<label for="password" class="form-label mb-3 mt-3">密码</label>
								<view class="flex align-center mb-2">
									<!-- <text class="mr-2">+86</text> -->
									<view class="align-stretch flex-1">
										<input type="password" v-model="registerPassword" class="border-bottom"
											placeholder="请输入密码" />
									</view>
								</view>
							</view>
							<view style="padding: 30px 20px;text-align: center;">
								<view class="flex align-center mb-2">
									<input class="border-bottom" v-model="graphicVerifyCode" placeholder="输入验证码" />
									<canvas style="width:220rpx;height:86rpx; border: black 1px solid;"
										canvas-id="canvas" @click="updateImageCode"></canvas>
								</view>
								<button v-show="!isPass" style="margin-top: 10px;" :loading="loading" @tap="submitFcha"
									class="btn btn-outline-primary btn-block rounded-4">验证</button>
							</view>
							<button v-show="isPass" type="submit" class="btn btn-primary btn-block rounded-4"
								@click="register">注册</button>
						</view>
					</template>
					<view class="flex align-center justify-center text-muted font-sm mt-4">
						注册即代表同意<text class="text-primary">《CityWalk协议》</text>
					</view>
					<!-- <other-login></other-login> -->
				</view>
			</transition>
		</view>
	</view>
</template>
<script>
	import {
		Fcaptcha
	} from '@/common/Fcaptcha';
	export default {
		data() {
			return {
				isPass: false,
				loading: false,
				graphicVerifyCode: "",
				currentTimeStamp: new Date().getTime(),
				status: false, //true账号密码，false为手机号登录
				username: '',
				password: '',
				loginCard: false, // 控制登录框显示与隐藏
				registerUsername: '', // 注册时的用户名
				registerNickname: '', // 注册时的昵称
				registerPassword: '', // 注册时的密码
			};
		},
		onShow() {
			this.fcaptcha = new Fcaptcha({
				el: 'canvas',
				width: 80,
				height: 35,
				createCodeImg: ""
			});

		},
		computed: {
			disabled() {
				if ((this.username === '' || this.password === '') || (this.registerUsername === '' || this
						.registerPassword === '' || this.registerNickname === '')) {
					return true
				}
			}
		},
		methods: {
			updateImageCode() {
				this.fcaptcha.refresh()
			},
			// 提交前校验图形验证码
			submitFcha() {
				if (!this.graphicVerifyCode) {
					return uni.showToast({
						icon: 'error',
						title: '请输入图形验证码'
					})
				}
				let validate = this.fcaptcha.validate(this.graphicVerifyCode)
				if (!validate) {
					this.updateImageCode();
					return uni.showToast({
						icon: 'error',
						title: '图形验证码错误'
					})
				} else {
					this.isPass = true
					return uni.showToast({
						title: '图形验证码通过'
					})
				}
			},
			initForm() {
				this.username = '';
				this.password = '';
				this.registerUsername = '';
				this.registerNickname = '';
				this.registerPassword = '';
			},
			changeStatus() {
				this.initForm(); // 重置表单
				this.status = !this.status; // 切换登录方式，默认是账号密码登录
				this.showRegisterCard = false; // 切换到登录时隐藏注册表单
			},
			showLoginCard() {
				this.loginCard = true;
			},
			register() {
				let that = this;
				// 发送注册请求，注意修改URL为你的实际接口地址
				uni.request({
					url: 'http://127.0.0.1:8002/api/user/register',
					method: 'POST',
					data: {
						username: that.registerUsername,
						user_nick_name: that.registerNickname,
						password: that.registerPassword,
						avatar: "/static/logo.png",
						background_image: "/static/logo.png",
						bio: "city walker",
						"create_time": this.$formatTimestamp(this.currentTimeStamp),
					},
					header: {
						'Content-Type': 'application/json'
					},
					success: (res) => {
						let that = this;
						// 检查用户名、昵称和密码是否为空
						if (!that.registerUsername.trim() || !that.registerNickname.trim() || !that
							.registerPassword.trim()) {
							uni.showToast({
								title: '用户名、昵称和密码均不能为空',
								icon: 'fail'
							});
							return;
						}
						if (res.statusCode === 200) {
							// 注册成功后的处理逻辑，例如跳转到登录页或者自动登录等
						} else {
							console.log(res.data);
							if (res.data === "Username is already taken") {
								uni.showToast({
									title: '用户名已存在，请重新输入',
									icon: 'none'
								});
								return;
							} else {
								this.initForm();
								this.status = !this.status;
								this.username = this.registerUsername
								this.password = this.registerPassword
								uni.showToast({
									title: '注册成功！',
									icon: 'none'
								})
							}

						}
					},
					fail: (Error) => {
						console.log(Error);
						uni.showToast({
							title: '注册失败，请重试',
							icon: 'none'
						})
					}
				})
			},

			submit() {
				let that = this;
				uni.request({
					url: 'http://127.0.0.1:8002/api/user/login',
					method: 'POST',
					data: {
						username: that.username,
						password: that.password
					},
					header: {
						'Content-Type': 'application/json'
					},
					success: (res) => {
						if (res.statusCode === 200) {
							getApp().globalData.C_Username = res.data.username;
							getApp().globalData.C_UserNickName = res.data.user_nick_name;
							getApp().globalData.C_UserId = res.data.id;
							getApp().globalData.C_UserAvatar = res.data.avatar;
							uni.switchTab({
								url: '/pages/mine/mine',
							})
						} else {
							console.log(res.data);
							uni.showToast({
								title: '登陆失败，请重试',
								icon: 'none'
							})
						}
					},
					fail: (Error) => {
						console.log(Error);
						uni.showToast({
							title: '登陆失败，请重试',
							icon: 'none'
						})
					}
				})
			},
		}
	};
</script>

<style scoped>
	.logo {
		width: 120px;
		height: 120px;
		border-radius: 50%;
		box-shadow: 10px -10px 60px rgba(63, 21, 0, 0.3);
	}

	.login-page {
		height: 100vh;
		display: flex;
		justify-content: center;
		align-items: center;
		background: linear-gradient(140deg, #e8e1e7 0%, #8fa0ff 100%);
		animation: slide-up 0.4s ease;
	}

	.login-card {
		background-color: #ffffff;
		padding: 40px;
		border-radius: 8px;
		box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.1);
		animation: slide-up 2s ease;
	}

	@keyframes slide-up {
		from {
			transform: translateY(20px);
			opacity: 0;
		}

		to {
			transform: translateY(0);
			opacity: 1;
		}
	}

	.fade-enter-active,
	.fade-leave-active {
		transition: opacity 1s ease;
	}

	.fade-enter,
	.fade-leave-to {
		opacity: 0;
	}
</style>