<template>
	<view>
		<view class="container mt-4">
			<view class="card">
				<view class="card-body mt-1">
					<uni-nav-bar left-icon="back" statusBar :border="false" @clickLeft="goBack"></uni-nav-bar>
					<!-- 文本域 -->
					<textarea v-model="detail" placeholder="分享你的CityWalk吧~~"
						class="lex align-center justify-center w-100"></textarea>
					<input v-model="description" placeholder="请输入标题"
						class="lex align-center justify-center w-100 border-bottom" />
					<div v-if="selectedLocation" class="selected-item">{{ selectedLocation.name }}</div>
					<div v-if="selectedTopic" class="selected-item">{{ selectedTopic.title }}</div>
				</view>
			</view>
		</view>
		<!-- 多图上传 -->
		<upload-image :show="show" ref="uploadImage" :list="imageList" @change="changeImage"></upload-image>
		<!-- 底部操作条 -->
		<view class="bottom-bar bg-white flex align-center">
			<view class="iconfont icon-tupian1 h2 mr-2 animated faster" hover-class="heartBeat"
				@click="iconClickEvent('uploadImage')"></view>
			<view class="iconfont icon-huati h2 mr-2 animated faster" hover-class="heartBeat" @click="selectTopic">
				<text class="text">话题</text>
			</view>
			<view class="iconfont icon-luxian h2 mr-2 animated faster" hover-class="heartBeat"
				@click="handleSelectedLocation">
				<text class="text">定位</text>
			</view>
			<view class="btn btn-primary btn-hover animated faster" hover-class="heartBeat"
				style="margin-left: auto; padding: 10px 20px;" @click="createNewPost">分享</view>
		</view>

	</view>
</template>

<script>
	import uniNavBar from '@/components/uni-ui/uni-nav-bar/uni-nav-bar.vue';
	import uniIcons from '@/components/uni-ui/uni-icons/components/uni-icons/uni-icons.vue'
	import uploadImage from '@/components/common/upload-image.vue';
	export default {
		components: {
			uniNavBar,
			uniIcons,
			uploadImage
		},
		data() {
			return {
				currentTimeStamp: new Date().getTime(),
				detail: '',
				imageList: [],
				description: '',
				showBack: false, //是否已经弹出提示框
				topics: [], // 存储话题列表
				selectedTopic: '', // 存储选择的话题
				selectedLocation: '', //存储选择的地点
				locations: [], // 存储地点列表
			}
		},
		computed: {
			show() {
				return this.imageList.length > 0
			}
		},
		onBackPress() {
			if ((this.detail !== '' || this.imageList.length > 0) && !this.showBack) {
				uni.showModal({
					detail: '是否要保存为草稿？',
					showCancel: true,
					cancelText: '不保存',
					confirmText: '保存',
					success: res => {
						if (res.confirm) {
							this.store()
						} else {
							uni.removeStorage({
								key: "add-input",
							})
						}
						uni.navigateBack({
							delta: 1
						});
					},
				});
				this.showBack = true
				return true
			}
		},
		// 页面加载
		onLoad() {
			uni.getStorage({
				key: "add-input",
				success: (res) => {
					let result = JSON.parse(res.data)
					this.detail = result.detail
					this.imageList = result.imageList
				}
			})
		},
		methods: {
			createNewPost() {
				if (this.description.trim() === '' || this.detail.trim() === '' || this.imageList.length === 0) {
					uni.showToast({
						title: '标题、详情和图片不能为空',
						icon: 'none'
					});
					return;
				}
				uni.request({
					url: "http://127.0.0.1:8002/api/post/create/post",
					method: 'POST',
					data: {
						"user_id": getApp().globalData.C_UserId,
						"topic_id": this.selectedTopic.id,
						"topic_name": this.selectedTopic.title,
						"business_id": this.selectedLocation.id,
						"business_name": this.selectedLocation.name,
						"description": this.description,
						"image_url": JSON.stringify(this.imageList),
						"detail": this.detail,
						"create_time": this.$formatTimestamp(this.currentTimeStamp),
					},
					success: (res) => {
						console.log(res.data);
						uni.showToast({
							title: '分享成功！',
						})
						uni.switchTab({
							url: '/pages/index/index'
						})
					},
					fail: (err) => {
						console.log(err.data);
					}
				})
			},
			handleSelectedLocation() {
				uni.showActionSheet({
					itemList: ['选择已有地点', '新建地点'],
					success: (res) => {
						if (res.tapIndex === 0) {
							this.getLocations();
						} else if (res.tapIndex === 1) {
							uni.navigateTo({
								url: '/pages/map/map-detail'
							});
						}
					},
				});
			},
			getLocations() {
				uni.request({
					url: "http://127.0.0.1:8002/api/business/all",
					method: 'GET',
					success: (res) => {
						this.locations = res.data; // 存储整个地点对象
						this.showLocationActionSheet();
					}
				})
			},
			showLocationActionSheet() {
				let locationNames = this.locations.map(location => location.name);
				// 对地点名称进行排序
				locationNames.sort((a, b) => a.localeCompare(b, 'zh'));
				uni.showActionSheet({
					itemList: locationNames,
					extraButtonOpen: true,
					success: (res) => {
						let selectedIndex = res.tapIndex;
						if (selectedIndex !== -1) {
							// 找到用户选择的是哪个名称
							let selectedLocationName = locationNames[selectedIndex];
							// 根据选择的名称找到对应的地点对象
							let selectedLocation = this.locations.find(location => location.name ===
								selectedLocationName);
							this.selectedLocation = selectedLocation; // 保留整个选中的地点对象
							console.log("Selected Location: ", selectedLocation);
						}
					},
				});
			},
			selectTopic() {
				uni.showActionSheet({
					itemList: ['选择已有话题', '新建话题'],
					success: (res) => {
						if (res.tapIndex === 0) {
							// 选择已有话题
							this.getTopics();
						} else if (res.tapIndex === 1) {
							// 新建话题
							uni.navigateTo({
								url: '/pages/create-topic/create-topic'
							})
						}
					},
				});
			},
			getTopics() {
				uni.request({
					url: "http://127.0.0.1:8002/api/topic/topics/info",
					method: 'GET',
					success: (res) => {
						this.topics = res.data;
						this.showActionSheet();
					}
				})
			},
			createNewTopic() {
				uni.prompt({
					title: '新建话题',
					placeholder: '请输入话题名称',
					success: (res) => {
						if (res.confirm && res.inputValue) {
							let newTopic = res.inputValue;
							this.selectedTopic = newTopic; // 将新建的话题赋值给 selectedTopic
						}
					},
				});
			},

			showActionSheet() {
				let topicTitles = this.topics.map(topic => topic.title);
				// 对话题标题进行排序
				topicTitles.sort((a, b) => a.localeCompare(b, 'zh'));
				uni.showActionSheet({
					itemList: topicTitles,
					extraButtonOpen: true,
					success: (res) => {
						let selectedIndex = res.tapIndex;
						if (selectedIndex !== -1) {
							// 找到用户选择的是哪个标题
							let selectedTopicTitle = topicTitles[selectedIndex];
							// 根据选择的标题找到对应的话题对象
							let selectedTopic = this.topics.find(topic => topic.title === selectedTopicTitle);
							this.selectedTopic = selectedTopic; // 保留整个选中的话题对象
							console.log("Selected Topic: ", selectedTopic.id);
						}
					},
				});
			},

			// 底部图片点击事件
			iconClickEvent(e) {
				switch (e) {
					case 'uploadImage':
						this.$refs.uploadImage.chooseImage()
						break;
				}
			},
			goBack() {
				uni.navigateBack({
					delta: 1
				})
			},
			changeImage(e) {
				this.imageList = e
			},
			// 保存为本地存储
			store() {
				uni.setStorage({
					key: 'add-input',
					data: JSON.stringify({
						detail: this.detail,
						imageList: this.imageList,
					})
				})
			}
		}
	}
</script>

<style>
	.bottom-bar {
		position: fixed;
		bottom: 0;
		left: 0;
		width: 100%;
		z-index: 999;
		background-color: #ffffff;
		box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
		padding: 10px 20px;
		display: flex;
		align-items: center;
	}

	.selected-item {
		margin-top: 10px;
		padding: 5px 10px;
		background-color: #f5f5f5;
		border-radius: 5px;
	}
</style>