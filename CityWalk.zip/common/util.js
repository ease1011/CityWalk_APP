export default {
	// 监听网络
	onNetWork() {
		let func = (res) => {
			if (res.networkType === 'none') {
				uni.showToast({
					title: '网络不好..加载失败....',
					icon: 'error'
				})
			}

		}


	},


}