// var gloableConfig = {
// 	"key": "88fa2a2a3594560538ab5fa496863bac", // 高德地图的key（配合秘钥使用的key）开发环境使用
// 	"secretKey": "15590c3309366ab6f8507b917408f096", // 高德地图的秘钥（配合key使用的秘钥）开发环境使用
// }
// // api请求前缀

// // websocket地址